<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * handles the admins
 * 
 * @since 1.0
 * @author DeDevelopers
 * @copyright Copyright (c) 2019, DeDevelopers, https://dedevelopers.com
 */
class RestApi extends ADMIN_Controller {
    private $guest_id;
    function __construct()
    {
        error_reporting(-1);
        parent::__construct();
    }

    public function get_restaurant_data($compid=0)
    {
        $post = json_decode(file_get_contents("php://input"));
        if(empty($post))
        $post = (object) $_POST;

        if($compid!=0){
            $rest_qry = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_companies` WHERE id = ".$compid)->result_object();
        } else {
             $rest_qry = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_companies`")->result_object();
        }

        if(empty($rest_qry)){
            echo json_encode(array("action"=>"failed","err"=>"No data found againts this restaurant."));
            return;
        }
        
        $final_data = array();
        
        foreach($rest_qry as $key => $data){
            $rating_data = array();
            $pics_data = array();
            $food_link = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_company_attributes` WHERE `company_id` = ".$data->id)->result_object()[0];

            $rating = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_company_ratings` WHERE `companyId` = ".$data->id)->result_object();

            if($data->typeId != ""){
                $type = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_company_types` WHERE `id` = ".$data->typeId)->result_object()[0];
            }
            
            $pictures = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_company_pictures` WHERE `picture_enable` = 1 AND `companyId` = ".$data->id)->result_object();

            $category = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_categories` WHERE `id` = ".$data->mainSubcategory)->result_object()[0];

            $country = $this->db->query("SELECT * FROM `ortez_jbusinessdirectory_countries` WHERE `id` = ".$data->countryId)->result_object()[0];

            // GET RATING
            $rating_plus = 0;
            if(!empty($rating)){
                foreach($rating as $key=> $rate){
                    $rating_data[] = array("rating"=>$rate->rating);
                    $rating_plus += $rate->rating; 
                }
            }

            $asset_url = "https://myzabihah.com/media/com_jbusinessdirectory/pictures/";
            // GET PICTURES
            foreach($pictures as $key=> $pic){
                $pics_data[] = array("image"=>$asset_url.$pic->picture_path);
            }
           

            $final_data[] = array(
                "id"        => $data->id,
                "name"      => $data->name,
                "slogan"    => $data->slogan,
                "alias"     => $data->alias,
                "s_descp"   => $data->short_description,
                "descp"     => $data->description,
                "street"    => $data->street_number,
                "address"   => $data->address,
                "city"      => $data->city,
                "post_code" => $data->postalCode,
                "state"     => $data->county,
                "country"   => $country->country_name,
                "website"   => $data->website,
                "phone"     => $data->phone,
                "logolocation"=> $asset_url.$data->logoLocation,
                "facebook"  => $data->facebook,
                "google"    => $data->googlep,
                "twitter"   => $data->twitter,
                "business_hours" => $data->business_hours,
                "food_ordering_link" => $food_link->value,
                "rating"    => $rating_data,
                "avg_rating" => !empty($rating)?$rating_plus/count($rating):0,
                "company_type" => $type->name,
                "pictures" => $pics_data,
                "category"  => $category->name,
            );
        }
   
        echo json_encode(array("action"=>"success","data"=>$final_data));
        
    }
}