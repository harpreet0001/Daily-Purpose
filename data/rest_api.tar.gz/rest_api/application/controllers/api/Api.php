<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

//regex_match[/^[0-9]{9,15}$/]

  private   $jwt_secret       = 'thisismysecretkey';
  private   $jwt_algo         = 'HS256';
  protected $validate_methods = [
                                  'changePassword',
                                  'addCompanyReviews',
                                  'userProfile',
                                  'addCompantToFavourite',
                                  'userLogout',
                                  'userProfileUpdate',
                                  'updateDeviceToken',
                                  'companyListing',
                                  'companyDetail'
                                ];
  protected $auth_user        = false;
  protected $isAuthorize      = false;
  protected $error_message    = '';
  // protected $SID              = "AC95be91694a0d9681407423c74805ff4f";
  // protected $AUTH_TOKEN       = "c1d8a36036da279cb814a2b18e8b1eb6";
  protected $SID              = "AC5c72c76af81e47414ae99f709886fc4e";
  protected $AUTH_TOKEN       = "80348a8bc8a0ee04fbd4024fdc1adac2";
  protected $baseUri          = "https://api.twilio.com";
  protected $otpLength        = 4;
  protected $twilio_phone_number = '+18455391679';

  //=======EMAIL-CONFIGRATION============//
    protected $Host       = 'mail.myzabihah.com';
    protected $SMTPAuth   = true;
    protected $Username   = 'noreply@myzabihah.com';
    protected $Password   = 'QQry7JxwzPDF7Z9822';
    protected $SMTPSecure = 'ssl';
    protected $Port       = 465;
  //=====================================//

  protected const SUCCESS = true;  
  protected const FAIL = false;  

  protected $image_basePath = "https://myzabihah.com/media/com_jbusinessdirectory/pictures";

  public function __construct() {
        
    parent::__construct();
    $this->load->helper(['jwt','api']);
    $this->load->database();
    $this->load->library('form_validation');
    $this->load->helper('url');
    
    if(in_array($this->router->fetch_method(), $this->validate_methods)) {

      $this->checkAuthorization($this->auth_user,$this->isAuthorize,$this->error_message);

    }


  }

  /*
    =================================================
                 Login Api
    =================================================
  */
  public function login()
  { 
    if ($this->input->server('REQUEST_METHOD') === 'POST') {


      $_POST = json_decode(file_get_contents('php://input'),true);
                
      /*=====Validation-Rules=====*/
       $config_rules = $this->loginValidationRules();
      /*=====Validation-Rules=====*/

      $this->form_validation->set_rules($config_rules,$_POST);
                 
      /*=====Validation-Fail=====*/ 
      if($this->form_validation->run() == FALSE) 
      {   
          $first_key   = array_key_first($this->form_validation->error_array());
          $first_error = $this->form_validation->error_array()[$first_key];

          /*================response/*================*/
          http_response_code(403); 
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => $first_error

              ]);
          return;
          /*================response/*================*/
      }

      $data = $_POST;

      $email        = isset($data['email'])        ? $data['email']        : '';
      $password     = isset($data['password'])     ? $data['password']     : '';
      $device_type  = isset($data['device_type'])  ? $data['device_type']  : '';
      $device_token = isset($data['device_token']) ? $data['device_token'] : '';

      /*=======================custom-validations==============================*/

        /*======================check-email-expression==============*/

          if(!empty($device_type) && !$this->chk_device_type_expression($device_type)) {
              
            /*================response/*================*/
                http_response_code(404);
                echo json_encode([

                      "result"  => Api::FAIL,
                      "message" => "Device type must be android or ios"
                ]);
                return;
            /*================response/*================*/ 
          }

      /*=======================================================================*/

      if(!empty($email) && !empty($password) && !empty($device_type) && !empty($device_token)) {
                
        /*====get-user-detail====*/
        $this->db->select('ou.*,
                          ouapi.id as ouapi_id,
                          ouapi.first_name,
                          ouapi.last_name,
                          ouapi.state,
                          ouapi.phone_number,
                          ouapi.tokens,
                          ouapi.fp_token'
                        );
        $this->db->from('ortez_users as ou');
        $this->db->join('ortez_users_api as ouapi', 'ou.id = ouapi.ortez_users_id', 'left'); 
        $this->db->where('ou.email', $email);
        $query = $this->db->get();


        if($query->num_rows() > 0) {

          $row = $query->row_array();

          /*=====verify-password=====*/
          if(! password_verify($password,$row['password'])) {
            
            /*================response/*================*/
            http_response_code(404);
            echo json_encode([

                  "result"  => Api::FAIL,
                  "message" => "Invalid credentials",
            ]);
            return;
            /*================response/*================*/
          }
          else
          {
             if((int)$row['block'] == 1)
             {  
                /*================response/*================*/
                http_response_code(404);
                echo json_encode([

                    "result"  => Api::FAIL,
                    "message" => "please check your email id to verify your email",

                ]);
                return;
                /*================response/*================*/
             }
             else
             {

                /*====generating-jwt-token====*/
                $token = $this->generateJWTToken([ 'id' => $row['id'],'email' => $row['email'] ]);

                $tokens = json_decode($row['tokens']);

                if(!empty($tokens) && !is_null($tokens) && is_array($tokens)) {

                    $new_token = array(
                                       
                                        'jwt'          => $token,
                                        'device_type'  => $_POST['device_type'],
                                        'device_token' => $_POST['device_token']
                                      );      
                                      

                    array_push($tokens, $new_token);
                }
                else
                {
                    $tokens = array(

                                    array(
                                       
                                      'jwt'          => $token,
                                      'device_type'  => $_POST['device_type'],
                                      'device_token' => $_POST['device_token']
                                    )      
                              );
                }

                $tokens = json_encode($tokens);

                if(empty($row['ouapi_id']) || is_null($row['ouapi_id'])) {

                  $data_api =  array('ortez_users_id' => $row['id'], 'tokens' => $tokens);
                  $this->db->insert('ortez_users_api',$data_api);

                }
                else
                {
                  /*update-tokens-db*/ 
                   $this->db->where('ortez_users_id',$row['id']);
                   $this->db->update('ortez_users_api',array('tokens' => $tokens));
                  /*update-tokens-db*/
                }
               

                $data = array(
                             
                             "id"           => isset($row["id"])           ?  (int)$row["id"]        : '',
                             "first_name"   => isset($row["first_name"])   ?  (string)$row["first_name"]     : '',
                             "last_name"    => isset($row["last_name"])    ?  (string)$row["last_name"]      : '',
                             "email"        => isset($row["email"])        ?  (string)$row["email"]          : '',
                             "state"        => isset($row["state"])        ?  (string)$row["state"]          : '',
                             "phone_number" => isset($row["phone_number"]) ?  (string)$row["phone_number"]   : '',
                             "access_token" => isset($token)               ?  $token                 : '',
                             "is_verify"    => isset($row["block"])        ?  (string)!$row["block"] : '0',
                             "device_type"  => $device_type,
                             "device_token" => $device_token,

                 );
                  
                  /*================response/*================*/
                  http_response_code(200);
                  echo json_encode([

                               "result"  => Api::SUCCESS,
                               "message" => "Login successfull",
                               "data"    => $data,
                  ]);
                  return;
                  /*================response/*================*/
               }

          }
            
        }
        else
        {
          /*================response/*================*/ 
          http_response_code(404);
          echo json_encode([

                       "result"  => Api::FAIL,
                       "message" => "Invalid credentials"
          ]);
          return;
          /*================response/*================*/
        }

      }
      else 
      {
        /*================response/*================*/
        http_response_code(404);
        echo json_encode([

                     "result"  => Api::FAIL,
                     "message" => "Inavlid parameters"
        ]);
        return;
        /*================response/*================*/
      }
      
    }
    else 
    {
        /*================response/*================*/
          http_response_code(404); 
          echo json_encode([

                   "result"  => Api::FAIL,
                   "message" => "Invalid method type"
          ]);
          return; 
        /*================response/*================*/
    }
  }

  /*
      =================================================
                 FORGET PASSWORD API
      =================================================
  */

    public function forgotPassword() {

      if($this->input->server('REQUEST_METHOD') == 'POST')
      {   
          $_POST = json_decode(file_get_contents('php://input'),true);

          /*=====Validation-Rules=====*/
          $config_rules = array(

              array(
                      'field' => 'email',
                      'label' => 'Email',
                      'rules' => 'required|trim|min_length[4]|max_length[200]'
                   ) 
          );
          /*=====Validation-Rules=====*/

          $this->form_validation->set_rules($config_rules,$_POST);
             
            /*=====Validation-Fail=====*/ 
            if($this->form_validation->run() == FALSE) 
            {
              $first_key   = array_key_first($this->form_validation->error_array());
              $first_error = $this->form_validation->error_array()[$first_key];

              /*================response/*================*/
                http_response_code(404);
                echo json_encode([

                            "result"  => Api::FAIL,
                            "message" => $first_error
                        ]);
                return;
              /*================response/*================*/
            }
            else
            {
               $data  = $_POST;
               $email = isset($data['email']) ? $data['email'] : '';
               /*=====check-useremail-exist=====*/
                $this->db->select('*');
                $this->db->from('ortez_users');
                $this->db->where('email', $email);
                $query = $this->db->get();

                if($query->num_rows() > 0) {
                    
                    $row = $query->row_array();

                    if((int)$row['block'] == 1)
                    {  
                      /*================response/*================*/
                        http_response_code(404);
                        echo json_encode([

                            "result"  => Api::FAIL,
                            "message" => "User not verified",

                        ]);
                        return;
                      /*================response/*================*/  
                    }
                    else
                    {
                      /*=====link-generate=====*/
                       $fp_token = $this->generateJWTToken([ 'id' => $row['id'],'email' => $row['email'] ]);
                       $forgot_password_link = base_url().'v1/reset/password?fp_token='.$fp_token;
                      /*=====link-generate=====*/

                      try
                      { 
                         $message = $this->load->view('email/password/reset',['forgot_password_link' => $forgot_password_link],true);

                         $this->sendMail($row['email'],'forget password mail',$message);
                         /*=====save-forgot-password-token=====*/
                            $this->db->where('ortez_users_id',$row['id']);
                            $this->db->update('ortez_users_api',array('tokens' => null,'fp_token' => $fp_token));
                          /*=====save-forgot-password-token=====*/
                          
                          /*================response/*================*/
                          http_response_code(200);
                          echo json_encode([

                                       "result"  => Api::SUCCESS,
                                       "message" => "Forget password link email sent to provided email id",
                          ]);
                          return;
                          /*================response/*================*/
                      }
                      catch(Exception $e)
                      {
                          /*================response/*================*/
                            http_response_code(400);
                            echo json_encode([

                                         "result"  => Api::FAIL,
                                         "message" => "Error while sending email",
                            ]);
                            return;
                          /*================response/*================*/
                      }

                    }
                }
                else
                { 
                  /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                         "result"  => Api::FAIL,
                         "message" => "User email does not exist"
                    ]);
                    return;
                  /*================response/*================*/  

                }
            }
      }
      else
      {
        /*================response/*================*/
        http_response_code(404); 
        echo json_encode([

                 "result"  => Api::FAIL,
                 "message" => "Invalid method type"
        ]); 
        return;
        /*================response/*================*/
      }
    }  


    /*
      =================================================
                 Register Api
      =================================================
    */
      
    public function register() {
          
      if($this->input->server('REQUEST_METHOD') === 'POST') {
             
        $_POST = json_decode(file_get_contents('php://input'),true);
                
        /*=====Validation-Rules=====*/
         $config_rules = $this->registerValidationRules();
        /*=====Validation-Rules=====*/

        $this->form_validation->set_rules($config_rules,$_POST);
                 
          /*=====Validation-Fail=====*/ 
          if($this->form_validation->run() == FALSE) 
          {
             $first_key   = array_key_first($this->form_validation->error_array());
             $first_error = $this->form_validation->error_array()[$first_key];

            /*================response/*================*/
              http_response_code(404);
              echo json_encode([

                    "result"  => Api::FAIL,
                    "message" => $first_error

                  ]);

              return;
            /*================response/*================*/
          }
          else
          {

              /*======================check-email-expression==============*/
              if(!empty($_POST['email']) && !$this->chk_email_expression($_POST['email'])) {
                  
                /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Invalid email"
                    ]);
                    return;
                /*================response/*================*/ 
              }

               /*======================check-phone-expression==============*/
              if(!empty($_POST['phone_number']) && !$this->chk_phone_expression($_POST['phone_number'])) {
                  
                /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Invalid phone number"
                    ]);
                    return;
                /*================response/*================*/ 
              }
              
              /*======================check-device-type-expression==============*/ 
              if(!empty($_POST['device_type']) && !$this->chk_device_type_expression($_POST['device_type'])) {
              
                /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Device type must be android or ios"
                    ]);
                    return;
                /*================response/*================*/ 
               }


              /*=====register-new-user=====*/
              $postData = $_POST;

              /*=====check-otp-is-valid=====*/
               $isValid = $this->isValidOtp($postData['phone_number'],$postData['otp']);
              /*============================*/

              if($isValid)
              {   
                  /*=====remove-otp=====*/
                   $this->removeOtp($postData['phone_number']);
                  /*====================*/

                  $this->db->insert('ortez_users',[

                      'name'          => $postData['first_name'].' '.$postData['last_name'], 
                      'username'      => $postData['username'],
                      'email'         => $this->convert_lowercase($postData['email']),
                      'password'      => $this->hash_password($postData['password']),
                      'block'         => 1,
                      'sendEmail'     => 0,
                      'registerDate'  => date('Y-m-d H:i:s'),
                      'lastvisitDate' => date('Y-m-d H:i:s')


                  ]);

                  $ortez_users_insert_id = $this->db->insert_id();

                  /*====generating-jwt-token====*/
                    $token = $this->generateJWTToken([
                                                       'id'    => $ortez_users_insert_id,
                                                       'email' => $this->convert_lowercase($postData['email'])
                                                    ]);
                  /*===========================*/

                  $tokens = array(
                                    array(
                                       
                                      'jwt'          => $token,
                                      'device_type'  => $_POST['device_type'],
                                      'device_token' => $_POST['device_token']
                                    )      
                                );

                  $tokens = json_encode($tokens);

                  $this->db->insert('ortez_users_api',[

                        'ortez_users_id' => $ortez_users_insert_id,
                        'first_name'     => $postData['first_name'],
                        'last_name'      => $postData['last_name'],
                        'state'          => $postData['state'],
                        'phone_number'   => $postData['phone_number'],
                        'tokens'         => $tokens
                  ]);

                  $ortez_users_api_insert_id = $this->db->insert_id();

                  /*====get-user-detail====*/
                  $this->db->select('ou.*,
                                    ouapi.id as ouapi_id,
                                    ouapi.first_name,
                                    ouapi.last_name,
                                    ouapi.state,
                                    ouapi.phone_number,
                                    ouapi.tokens,
                                    ouapi.fp_token'
                                  );
                  $this->db->from('ortez_users as ou');
                  $this->db->join('ortez_users_api as ouapi', 'ou.id = ouapi.ortez_users_id', 'left'); 
                  $this->db->where('ou.id',$ortez_users_insert_id);
                  $query = $this->db->get();

                  $row = $query->row_array();

                   $responeData = array(

                        "id"           => (int)$row["id"], 
                        "first_name"   => $row["first_name"],
                        "last_name"    => $row["last_name"],
                        "email"        => $row["email"],
                        "state"        => $row["state"],
                        "phone_number" => $row["phone_number"],
                     //   "access_token" => $token,
                        "is_verify"    => '0',
                        "device_type"  => $postData['device_type'],
                        "device_token" => $postData['device_token']
                  );
                  
                  /*================response/*================*/
                    // http_response_code(201);
                    // echo json_encode([

                    //           "result"  => Api::SUCCESS,
                    //           "message" => "Register successfully",
                    //           "data"    => $responeData
                    // ]);
                    // return;
                  /*================response/*================*/

                  try {

                      /*======================SENDING-VERIFICATION-EMAIL=====================*/
                          $this->sendVerificationEmail($row['id']);
                      /*======================SENDING-VERIFICATION-EMAIL=====================*/

                      http_response_code(200);
                      echo json_encode([

                            "result"  => Api::SUCCESS,
                            "message" => "Please verify your email first before login",
                            "data"    => $responeData
                      ]);
                      return;
                  }
                  catch(Exception $e) {

                    /*================response/*================*/
                          http_response_code(404);
                          echo json_encode([

                                "result"  => Api::FAIL,
                                "message" => "Error while sending email",
                                "data"    => $e->getMessage()
                          ]);
                          return;
                    /*================response/*================*/
                  }
                 
              }
              else
              {
                 /*================response/*================*/  
                  http_response_code(404);
                  echo json_encode([

                      "result"  => Api::FAIL,
                      "message" => "Invalid or expired otp token"
                  ]);
                  return;
                /*================response/*================*/  
              }

          }
      }
      else
      {   
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

              "result"  => Api::FAIL,
              "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/  
      }

    }


    /*
      =================================================
                RESEND-OTP
      =================================================
    */
    public function resendOTP() {
         

        if($this->input->server('REQUEST_METHOD') == 'POST')
        {
            $_POST = json_decode(file_get_contents('php://input'),true);

            /*=====Validation-Rules=====*/
            $config_rules = array(
              
                array(

                 'field' => 'phone_number',
                 'label' => 'Phone number',
                 'rules' => 'required|trim|min_length[5]|max_length[15]'
                )
            );
            /*=====Validation-Rules=====*/

            $this->form_validation->set_rules($config_rules,$_POST);

            if($this->form_validation->run() == FALSE) 
            {
               $first_key   = array_key_first($this->form_validation->error_array());
               $first_error = $this->form_validation->error_array()[$first_key];
                
                /*================response/*================*/  
                http_response_code(404);
                echo json_encode([

                              "result"  => Api::FAIL,
                              "message" => $first_error
                ]);
                return;
                /*================response/*================*/  
            }
            else
            {
                /*=====resend-otp=====*/
                $to_phone_number = $_POST['phone_number'];
                $otp = $this->generateRandomNumber($this->otpLength);

                $otp_message = '# Onetime password is: '.$otp;

                try {
                     
                    /*==============Sending-OTP===============*/
                     $this->sendSMS($this->twilio_phone_number,$to_phone_number,$otp_message);

                    /*update-otp-db*/
                      $this->db->select('*');
                      $this->db->from('ortez_users_otp');
                      $this->db->where(array('phone_number' => $to_phone_number));
                      $query = $this->db->get();

                      $date         = new DateTime();
                      $created_time = $date->getTimestamp();
                      $expired_time = $date->getTimestamp() + 60*5;

                      if($query->num_rows() > 0) {

                          $row = $query->row_array();

                          $data_token =  array(

                                              'otp'          => $otp,
                                              'created_time' => $created_time,
                                              'expired_time' => $expired_time
                                            );

                          $this->db->where('id',$row['id']);
                          $this->db->update('ortez_users_otp',$data_token);

                      }
                      else
                      {   

                        $data_token =  array(
                                               'phone_number' => $to_phone_number,
                                               'otp'          => $otp,
                                               'created_time' => $created_time,
                                               'expired_time' => $expired_time
                                            );

                        $this->db->insert('ortez_users_otp',$data_token);
                      }  
                    /*update-otp-db*/
                    
                    /*================response/*================*/               
                      http_response_code(200);
                      echo json_encode([

                           "result"  => Api::SUCCESS,
                           "message" => "Otp send to registered phone number",
                      ]);
                      return;
                    /*================response/*================*/  
                  }
                  catch(Exception $e) 
                  {
                    /*================response/*================*/  
                      http_response_code(400);
                      echo json_encode([

                         "result"  => Api::FAIL,
                         "message" => $e->getMessage()

                      ]);
                      return;
                    /*================response/*================*/    
                  }
            }
        }
        else
        {
          /*================response/*================*/  
            http_response_code(404);
            echo json_encode([

                 "result"  => Api::FAIL,
                 "message" => "Invalid method type"
            ]);
            return;
          /*================response/*================*/    
        }
    }
      


    /*
      =================================================
                CHECK USER EXIST
      =================================================
    */
     
     public function checkUserExist() {

        if($this->input->server('REQUEST_METHOD') == 'POST') {

          $_POST = json_decode(file_get_contents('php://input'),true);

          /*=====Validation-Rules=====*/
            $config_rules = array(
              
             
                array(

                 'field' => 'email',
                 'label' => 'Email',
                 'rules' => 'required|trim|min_length[4]|max_length[200]'
                ),
                array(

                 'field' => 'phone_number',
                 'label' => 'Phone number',
                 'rules' => 'required|trim|min_length[5]|max_length[15]'
                )
            );
          /*=====Validation-Rules=====*/

          $this->form_validation->set_rules($config_rules,$_POST);

          if($this->form_validation->run() == FALSE) 
          {   
              $first_key   = array_key_first($this->form_validation->error_array());
              $first_error = $this->form_validation->error_array()[$first_key];
              
              /*================response/*================*/ 
                http_response_code(404);
                echo json_encode([

                            "result"  => Api::FAIL,
                            "message" => $first_error
                        ]);
                return;
              /*================response/*================*/  
          }
          else
          {   
              $email = $_POST['email'];
              $to_phone_number = $_POST['phone_number'];

              /*======================check-email-expression==============*/
              if(!empty($email) && !$this->chk_email_expression($email)) {
                  
                /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Invalid email"
                    ]);
                    return;
                /*================response/*================*/ 
              }

              if(!empty($to_phone_number) && !$this->chk_phone_expression($to_phone_number)) {
                  
                /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Invalid phone number"
                    ]);
                    return;
                /*================response/*================*/ 
              }

              /*======check-user-exist=====*/
              $this->db->select('ortez_users.*,ortez_users_api.*');
              $this->db->from('ortez_users');
              $this->db->join('ortez_users_api', 'ortez_users.id = ortez_users_api.ortez_users_id', 'left'); 
              $this->db->where('ortez_users.email', $email);
              $this->db->or_where('ortez_users_api.phone_number', $to_phone_number);
              $query = $this->db->get();
              /*===========================*/

              if($query->num_rows() > 0)
              {
                /*================response/*================*/
                  http_response_code(404);
                  echo json_encode([

                       "result"  => Api::FAIL,
                       "message" => "User is already exist",
                  ]);
                  return;
                /*================response/*================*/  
              }

              $otp = $this->generateRandomNumber($this->otpLength);

              $otp_message = '# Onetime password is: '.$otp;
              /*=====sending-otp-phone=====*/
              try {
                    
                  /*==============Sending-OTP===============*/
                   $this->sendSMS($this->twilio_phone_number,$to_phone_number,$otp_message);

                  /*update-otp-db*/
                    $this->db->select('*');
                    $this->db->from('ortez_users_otp');
                    $this->db->where(array('email' => $email,'phone_number' => $to_phone_number));
                    $query = $this->db->get();

                    $date         = new DateTime();
                    $created_time = $date->getTimestamp();
                    $expired_time = $date->getTimestamp() + 60*5;

                    if($query->num_rows() > 0) {

                        $row = $query->row_array();

                        $data_token =  array(

                                            'otp'          => $otp,
                                            'created_time' => $created_time,
                                            'expired_time' => $expired_time
                                          );

                        $this->db->where('id',$row['id']);
                        $this->db->update('ortez_users_otp',$data_token);

                    }
                    else
                    {   

                      $data_token =  array(

                                             'email'        => $email,
                                             'phone_number' => $to_phone_number,
                                             'otp'          => $otp,
                                             'created_time' => $created_time,
                                             'expired_time' => $expired_time
                                          );

                        $this->db->insert('ortez_users_otp',$data_token);
                    }  
                  /*update-otp-db*/
                  
                  /*================response/*================*/             
                    http_response_code(200);
                    echo json_encode([

                         "result"  => Api::SUCCESS,
                         "message" => "Otp send to registered phone number",
                    ]);
                    return;
                  /*================response/*================*/
                }
                catch(Exception $e) 
                {
                  /*================response/*================*/
                    http_response_code(400);
                    echo json_encode([

                       "result"  => Api::FAIL,
                       "message" => $e->getMessage()

                    ]);
                    return;
                  /*================response/*================*/  
                }
              /*=====sending-otp-phone=====*/
          }

        }
        else
        { 
          /*================response/*================*/  
            http_response_code(404);
            echo json_encode([

                  "result"  => Api::FAIL,
                  "message" => "Invalid method type"
              ]);
            return;
          /*================response/*================*/
        }
    }

   
    /*
      =================================================
              CHANGE PASSWORD
      =================================================
    */
    public function changePassword() {

      /*======check-authorize=====*/
      if(!$this->isAuthorize) {

        http_response_code(404);
        echo json_encode([

            "result"  => Api::FAIL,
            "message" => "Invalid Authentication"
        ]);

        return;
      }
      /*======check-authorize=====*/


      if($this->input->server('REQUEST_METHOD') == 'POST') {

        $_POST = json_decode(file_get_contents('php://input'),true);

          /*=====Validation-Rules=====*/
            $config_rules = array(

                array(

                 'field' => 'old_password',
                 'label' => 'Old Password',
                 'rules' => 'required|trim|min_length[5]|max_length[200]'
                ),
                array(

                 'field' => 'new_password',
                 'label' => 'New Password',
                 'rules' => 'required|trim|min_length[5]|max_length[200]'
                )
            );
          /*=====Validation-Rules=====*/

          $this->form_validation->set_rules($config_rules,$_POST);

          if($this->form_validation->run() == FALSE) 
          {   
              $first_key   = array_key_first($this->form_validation->error_array());
              $first_error = $this->form_validation->error_array()[$first_key];
              
              /*================response/*================*/
              http_response_code(404);
              echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => $first_error
                      ]);
              return;
              /*================response/*================*/
          }
          else
          {
              $user = $this->auth_user;
              $old_password = $_POST['old_password'];
              $new_password = $_POST['new_password'];

              if(! password_verify($old_password,$user['password'])) {

                 /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Old password does not matched"
                      ]);
                    return;
                  /*================response/*================*/  
              }
              else
              {  
                  if($old_password == $new_password) {

                      /*================response/*================*/
                      http_response_code(404);
                      echo json_encode([

                            "result"  => Api::FAIL,
                            "message" => "New password must be different"
                        ]);
                      return;
                    /*================response/*================*/
                  }

                  $new_hash_password = $this->hash_password($new_password);

                  $this->db->where('id',$user['id']);
                  $this->db->update('ortez_users',array('password' => $new_hash_password));

                  /*=================delete-Access-Token==================*/
                  $this->removeAccessToken($user['id'],$user['token']);

                  /*================response/*================*/
                    http_response_code(200);
                    echo json_encode([

                          "result"  => Api::SUCCESS,
                          "message" => "Password changed successfully"
                      ]);
                    return;
                  /*================response/*================*/
              } 
          }
      }
      else
      {  
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
            ]);
          return;
        /*================response/*================*/  
      }
  }

  /*
      =================================================
               RESET-PASSWORD
      =================================================
  */
  public function resetPassword() 
  {
      $fp_token = $this->input->get('fp_token');

      if(!empty($fp_token) || !is_null($fp_token)) {
        
        try {

              $jwt = new JWT();
              $result = $jwt->decode($fp_token,$this->jwt_secret, $verify = true);
              
              $iat = $result->iat;
              $exp = $result->exp;
              $now = strtotime("now"); 
              /*=====check-validity=====*/
              if($iat < $now && $now > $exp) {
                
                http_response_code(404);  
                echo json_encode(['error' => 'TokenExpired']);
                return;

              }
              /*=====check-validity=====*/

              if($result)
              {    
                  $email = $result->email;
                  $id    = $result->id;
             
                  /*=====check-user-exist-in-db=====*/
                  $this->db->select('ou.*,
                                    ouapi.id as ouapi_id,
                                    ouapi.first_name,
                                    ouapi.last_name,
                                    ouapi.state,
                                    ouapi.phone_number,
                                    ouapi.tokens,
                                    ouapi.fp_token'
                                  );
                  $this->db->from('ortez_users as ou');
                  $this->db->join('ortez_users_api as ouapi', 'ou.id = ouapi.ortez_users_id', 'left'); 
                  $this->db->where('ou.email', $email);
                  $this->db->where('ou.id', $id);
                  $query = $this->db->get();

                  if($query->num_rows() > 0) {
                      
                    $row  = $query->row_array();

                    if((int)$row['block'] == 1) {
                        
                        /*================response/*================*/
                          http_response_code(404);
                          echo json_encode(['error' => 'User not verified']);
                          return;
                        /*================response/*================*/
                    }
                    else
                    {

                       if($row['fp_token'] != $fp_token) {
                          
                          /*================response/*================*/
                          http_response_code(404);
                          echo json_encode(['error' => 'Token is expired']);
                          return;
                          /*================response/*================*/
                       }
                       if($this->input->server('REQUEST_METHOD') == 'GET')
                       {
                          /*=====check-user-exist*/
                          return $this->load->view('api/password/reset',['fp_token' => $fp_token,'id' => $id,'email' => $email]);
                       }
                       else if($this->input->server('REQUEST_METHOD') == 'POST')
                       {
                              /*=====Validation-Rules=====*/
                              $config_rules = array(

                                  array(
                                          'field' => 'password',
                                          'label' => 'Password',
                                          'rules' => 'required|trim|min_length[4]|max_length[200]'
                                       ),
                                  array(
                                          'field' => 'confirm_password',
                                          'label' => 'Confirm password',
                                          'rules' => 'required|trim|min_length[4]|max_length[200]|matches[password]'
                                       )      
                              );
                              /*=====Validation-Rules=====*/

                              $this->form_validation->set_rules($config_rules);
                                 
                              /*=====Validation-Fail=====*/ 
                              if($this->form_validation->run() == FALSE) 
                              {
                                 return $this->load->view('api/password/reset',['fp_token' => $fp_token,'id' => $id,'email' => $email]);
                              }
                              else
                              {
                                  $new_password = $this->hash_password($_POST['password']);

                                  /*=====update-password=====*/

                                    $this->db->where('id',$row['id']);
                                    $this->db->update('ortez_users',array('password' => $new_password));

                                      /*=====remove-fp_token=====*/
                                        $this->db->where('ortez_users_id',$row['id']);
                                        $this->db->update('ortez_users_api',array('tokens' => null,'fp_token' => ''));
                                      /*=====remove-fp_token=====*/ 

                                      /*================response/*================*/  
                                      http_response_code(200);   
                                      echo json_encode(['success' => 'Password is updated']);
                                      return;
                                      /*================response/*================*/

                                  /*=====update-password=====*/
                              }
                       }
                    }

                  }
                  else
                  {  
                     /*================response/*================*/ 
                      http_response_code(404);
                      echo json_encode(['error' => 'Invalid request token']);
                      return;
                      /*================response/*================*/
                  }        

              }
              else
              {  
                /*================response/*================*/
                 http_response_code(404);
                 echo json_encode(['error' => 'Invalid request token']);
                 return;
                 /*================response/*================*/
              }
 
        }
        catch(Exception $e) {
          
          /*================response/*================*/ 
           http_response_code(404); 
           echo json_encode(['error' => 'Invalid request token']);
           return;
          /*================response/*================*/ 
        }
      }
      else
      { 
        /*================response/*================*/ 
         http_response_code(404);
         echo json_encode(['error' => 'Invalid request token']);
         return;
        /*================response/*================*/ 
      }
  }


  /*
      =================================================
               BUSINESS-LISTING
      =================================================
  */
  public function companyListing() 
  {
      if($this->input->server('REQUEST_METHOD') == 'POST')
      {   
          $_POST = json_decode(file_get_contents('php://input'),true);

          if(isset($_POST['page']) || isset($_POST['per_page']))
          {
              /*=====Validation-Rules=====*/
                $rules = array(

                    array(

                     'field' => 'per_page',
                     'label' => 'per_page',
                     'rules' => 'trim|integer|greater_than[0]'
                    ),
                    array(

                     'field' => 'page',
                     'label' => 'page',
                     'rules' => 'trim|integer|greater_than[0]'
                    ),
                    array(

                       'field' => 'latitude',
                       'label' => 'latitude',
                       'rules' => 'numeric|greater_than[-90]|less_than[90]',
                    ),
                    array(

                       'field' => 'longitude',
                       'label' => 'longitude',
                       'rules' => 'numeric|greater_than[-180]|less_than[180]',
                    )
                );
             /*=====Validation-Rules=====*/

              $this->form_validation->set_rules($rules,$_POST);

              if($this->form_validation->run() == FALSE) 
              {   
                  $first_key   = array_key_first($this->form_validation->error_array());
                  $first_error = $this->form_validation->error_array()[$first_key];

                  /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                                "result"   => Api::FAIL,
                                "message"  => $first_error
                            ]);
                    return;
                  /*================response/*================*/ 
              }
          }


          $type = 'all';
          $companyIds = [];

          if(isset($_POST['type']))
          {
             if($_POST['type'] == 'favourite')
             {
                /*===========================check-authorization===========================*/
                   //$this->checkAuthorization($this->auth_user,$this->isAuthorize,$this->error_message);

                  if(!$this->isAuthorize) {

                    http_response_code(404);
                    echo json_encode([

                        "result"  => false,
                        "message" => "Invalid Authentication"
                    ]);

                    return;
                  }
                /*===========================check-authorization===========================*/

                  $type = 'favourite';

                  $user = $this->auth_user;

                  $this->db->select('*');
                  $this->db->from('ortez_jbusinessdirectory_companies_favourite');
                  $this->db->where('user_id',$user['id']);
                  $query = $this->db->get();

                  if($query->num_rows() > 0) {
                       
                      $result = $query->result_array();
                      $companyIds = array_column($result, 'company_id');
                  }

             }
            else if($_POST['type'] == 'featured') {

                $type = 'featured';
            }
          }

          $records = [];

          $latitude  = isset($_POST['latitude'])  ? $_POST['latitude'] : "";
          $longitude = isset($_POST['longitude']) ? $_POST['longitude'] : "";

          if(!empty($latitude) && !empty($latitude)) {
  
             //$this->db->select('*,(acos(sin('.$latitude.') * sin(latitude) + cos('.$latitude.') * cos(latitude) * cos(longitude - ('.$longitude.'))) * 6371) as distance');

             $this->db->select('*,((
                            (
                                acos(
                                    sin(( '.$latitude.' * pi() / 180))
                                    *
                                    sin(( `latitude` * pi() / 180)) + cos(( '.$latitude.' * pi() /180 ))
                                    *
                                    cos(( `latitude` * pi() / 180)) * cos(((  '.$longitude.' - `longitude`) * pi()/180)))
                            ) * 180/pi()
                        ) * 60 * 1.1515 * 1.609344)
        
             as distance');
          }
          else
          {
             $this->db->select('*');
          }

          $this->db->from('ortez_jbusinessdirectory_companies');
          $this->db->where('approved',2);
          $this->db->where('state',1);

          if($type == 'favourite')
          {  
             if(count($companyIds) == 0) {
               $companyIds = [-1];
             }
             $this->db->where_in('id',$companyIds);
          }
          else if($type == 'featured') {
             
             $this->db->where('featured',1);
          }
         
          if(!empty($latitude) && !empty($latitude)) {

            $this->db->order_by('distance','asc');
          }

          $query = $this->db->get();

          if($query->num_rows() > 0)
          {
              $companies = $query->result();

              foreach ($companies as $company) {

                  $food_type_arr       = [];
                  $company_picture_arr = [];
                  $services_arr        = $this->companyServices($company->id);
                  $halalStatus         = $this->companyHalalStatus($company->id);
                  $rating              = $this->companyRating($company->id);

                  $order_link          = $this->orderLink($company->id);

                  $companyState = $this->companyUsState($company->id);
                  $state_name   = $companyState["state_name"];
                  $state_id     = $companyState["state_id"];
 
                  $company_categories = $this->companyCategories($company->id);

                  if(count($company_categories) > 0) {

                      foreach ($company_categories as $company_category) {
                       
                          $food_type_arr[] = $company_category['name'];
                      }

                  }

                  $company_picture_arr = $this->companyPictures($company->id);

                  $rating = number_format($rating,1,'.',''); 
                  $rating = (float)($rating);
               
                  $records[] = [
                                      'id'                => (int)$company->id,
                                      'name'              => $company->name,
                                      'image'             => $company_picture_arr,
                                      'food_type'         => $food_type_arr,
                                      "city"              => $company->city,
                                      "state_name"        => $state_name,
                                      "state_id"          => $state_id,
                                      "province"          => $company->province,
                                      "postalCode"        => $company->postalCode,
                                      "address"           => $company->city.', '.$company->province.' '.$company->postalCode,
                                      "full_address"      => $company->street_number.' '.$company->address.', '.$company->city.', '.$company->province.' '.$company->postalCode,
                                      "latitude"          => ($company->latitude  != '') ? (double)($company->latitude)  : 0,
                                      "longitude"         => ($company->longitude != '') ? (double)($company->longitude) : 0,
                                      'distance'          => isset($company->distance) ? $company->distance : null,
                                      "is_featured"       => ($company->featured == 1) ? true : false,
                                      "short_description" => $company->short_description,
                                      "description"       => $company->description,
                                      "services"          => $services_arr,
                                      "halal"             => $halalStatus,
                                      "order_link"        => $order_link,
                                      "rating"            => $rating,
                                    ]; 
              }


              /*===================Filter-By-Food-Type=====================*/
              if(isset($_POST['food_type']) && count($records) > 0) {

                $search_food_type = strtolower($_POST['food_type']);

                if(!empty($search_food_type) && $search_food_type != 'all') {

                    $search_food_type_ids  = explode(',', $search_food_type);
                    $search_food_type_names_Arr = [];

                    $this->db->select('name,id');
                    $this->db->from('ortez_jbusinessdirectory_categories');
                    $this->db->where(array('published' => '1', 'level' => '1', 'type' => '1'));
                    $this->db->where_in('id',$search_food_type_ids);

                    $query = $this->db->get();
                    $row_count = $query->num_rows();

                    if($row_count > 0) {
                          
                      $result = $query->result_array();

                      $search_food_type_names_Arr = array_column($result,'name');
                   
                    }

                    if(count($records) > 0 && count($search_food_type_names_Arr) > 0 ) {

                        $records =  array_filter($records,function($record) use($search_food_type_names_Arr) {

                                      if(count(array_intersect($search_food_type_names_Arr, $record['food_type'])) > 0) {

                                           return true;
                                      }

                                    });
                    }
                    else
                    {
                        $records = [];
                    }

                }
              }
              /*===================Filter-By-Food-Type=====================*/


              /*===================Filter-By-State=====================*/
              if(isset($_POST['state']) && count($records) > 0) {

                $search_state = strtolower($_POST['state']);

                if(!empty($search_state) && $search_state != 'all') {

                    $search_state_ids  = explode(',', $search_state);

                    if(count($records) > 0 && count($search_state_ids) > 0) {

                        $records =  array_filter($records,function($record) use($search_state_ids) {
                                        
                                          if(in_array($record['state_id'],$search_state_ids)) {

                                             return true;
                                          }  
                                    });
                    }
                    else
                    {
                        $records = [];
                    }

                }
              }
              /*===================Filter-By-State=====================*/


             /*=====================Filter-By-Search=======================*/
              if(isset($_POST['search']) && count($records) > 0) {

                $search = strtolower($_POST['search']);

                if(!empty($search)) {

                  $records = array_filter($records,function($record) use($search){

                                $companyName = strtolower($record['name']);

                                if (strpos($companyName, $search) !== false) 
                                { 
                                  return true; 
                                }
                                else
                                {
                                  return false;
                                }

                              });
                }
              }
              /*=====================Filter-By-Search=======================*/


              /*========================Sorting==============================*/
              $sort = SORT_ASC;
              if(isset($_POST['sort_reverse']) && $_POST['sort_reverse']) {
                  $sort = SORT_DESC;                  
              }

              if(isset($_POST['sort']) && !empty($_POST['sort']) && count($records) > 0) {

                $sortingArr = ['name','city','rating'];
                $sortBy     = strtolower($_POST['sort']);

                if(in_array($sortBy,$sortingArr)) {
                  array_multisort(array_column($records, $sortBy), $sort, $records);  
                }

              }
              /*========================Sorting==============================*/


              /*==============================Pagination-End===============================*/
                $recordCount       = count($records);
                $page              = 1;
                if(!empty($_POST['page'])) {$page = (int)$_POST['page']; }

                $result_per_page   = 10;
                if(!empty($_POST['per_page'])) { $result_per_page = (int)$_POST['per_page'];}

                $page_first_result = ($page-1) * $result_per_page;
                $number_of_page    = ceil ( $recordCount / $result_per_page); 

                $records = array_slice($records,$page_first_result,$result_per_page);
              /*==============================Pagination-End===============================*/
               
               $data = [];

               if(count($records) > 0) {
                 
                 $data = [
                            "data"         => $records,
                            "current_page" => $page,
                            "last_page"    => $number_of_page,
                            "per_page"     => $result_per_page,
                            "total"        => $recordCount
                         ];

               }
               
               /*================response/*================*/
               ini_set('precision', 10);
               ini_set('serialize_precision', 10);
               http_response_code(200);
               $message = "Data found";
               if(count($records) == 0) { $message = "Data not found"; }
               echo json_encode([

                    "result"  => Api::SUCCESS,
                    "message" => $message,
                    "data"    => $data
               ]);
               return;
               /*================response/*================*/

          }
          else
          { 
            /*================response/*================*/
              http_response_code(200);
              echo json_encode([

                    "result"  => Api::SUCCESS,
                    "message" => "No data found"
              ]);
              return;
            /*================response/*================*/  
          }
      }
      else
      { 
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/  
      }
  }

  
  /*
      =================================================
               COMPANY-Detail
      =================================================
  */

  public function companyDetail() {
       
      if($this->input->server('REQUEST_METHOD') == 'GET')
      {   
          $id = isset($_GET['id']) ? $_GET['id'] : '';

          if(empty($id) || is_null($id)) 
          {
            /*================response/*================*/
              http_response_code(404); 
              echo json_encode([

                    "result"  => Api::FAIL,
                    "message" => "Invalid parameters",

                  ]);

              return;
            /*================response/*================*/  
          }
          else
          {
              $this->db->select('*');
              $this->db->where('id',$id);
              $this->db->where('approved',2);
              $this->db->where('state',1);
              $this->db->from('ortez_jbusinessdirectory_companies');
              $query = $this->db->get();

                if($query->num_rows() > 0)
                {

                  $company = $query->row();

                  $food_type_arr       = [];
                  $company_picture_arr = [];
                  $services_arr        = $this->companyServices($company->id);
                  $halalStatus         = $this->companyHalalStatus($company->id);
                  $rating              = $this->companyRating($company->id);
                  $order_link          = $this->orderLink($company->id);
                  $companyState        = $this->companyUsState($company->id);
                  $state_name          = $companyState["state_name"];
                  $state_id            = $companyState["state_id"];
 
                  $company_categories = $this->companyCategories($company->id);

                  if(count($company_categories) > 0) {

                      foreach ($company_categories as $company_category) {
                       
                          $food_type_arr[] = $company_category['name'];
                      }

                  }

                  $company_picture_arr = $this->companyPictures($company->id);

                  $is_reviewed = false;
                  $is_fav      = false;
                  
                  if($this->isAuthorize) {

                      $user = $this->auth_user;

                      $this->db->select('*');
                      $this->db->where(array('itemId' => $company->id, 'userId' => $user['id']));
                      $this->db->from('ortez_jbusinessdirectory_company_reviews');
                      $reviewQuery = $this->db->get();

                      if($reviewQuery->num_rows() > 0) {
                        $is_reviewed = true;
                      }

                      $this->db->select('*');
                      $this->db->from('ortez_jbusinessdirectory_companies_favourite');
                      $this->db->where(array('user_id' => $user['id'],'company_id' => $company->id));
                      $favQuery = $this->db->get();

                      if($favQuery->num_rows() > 0) {

                         $is_fav = true;
                      }                    
                  }

                  $rating = number_format($rating,1,'.',''); 
                  $rating = (float)($rating);
               
                  $record = [

                                      'id'                => (int)$company->id,
                                      'image'             => $company_picture_arr,
                                      'name'              => $company->name,
                                      'food_type'         => $food_type_arr,
                                      "address"            => $company->city.', '.$company->province.' '.$company->postalCode,
                                      "full_address"      => $company->street_number.' '.$company->address.', '.$company->city.', '.$company->province.' '.$company->postalCode,
                                      "city"              => $company->city,
                                      "state_name"        => $state_name,
                                      "state_id"          => $state_id,
                                      "rating"            =>  $rating,
                                      "latitude"          => ($company->latitude  != '') ? (double)($company->latitude)  : 0,
                                      "longitude"         => ($company->longitude != '') ? (double)($company->longitude) : 0,
                                      "is_featured"       => ($company->featured == 1) ? true : false,
                                      "services"          => $services_arr,
                                      "halal"             => $halalStatus,
                                      "short_description" => $company->short_description,
                                      "description"       => $company->description,
                                      "is_reviewed"       => $is_reviewed,
                                      "is_fav"            => $is_fav,
                                      "order_link"        => $order_link,
                                      
                            ];
                  
                  /*================response/*================*/
                  ini_set('precision', 10);
                  ini_set('serialize_precision', 10);
                    http_response_code(200);
                    echo json_encode([

                            "result"  => Api::SUCCESS,
                            "message" => "Record found",
                            "data"    => $record
                    ],JSON_NUMERIC_CHECK);
                    return;
                  /*================response/*================*/

                }
                else
                {
                  /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Record not found"
                    ]);
                    return;
                  /*================response/*================*/  
                }
          }

      }
      else
      {
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/  
      }    
  }

  
  /*
      =================================================
               ADD-COMPANY-TO-FAVOURITE
      =================================================
  */
  public function addCompantToFavourite() {
      
      if($this->input->server('REQUEST_METHOD') == 'POST')
      {  
          /*======check-authorize=====*/
            if(!$this->isAuthorize) {

              http_response_code(404);
              echo json_encode([

                  "result"  => Api::FAIL,
                  "message" => "Invalid Authentication"
              ]);

              return;
            }
         /*======check-authorize=====*/

         $_POST = json_decode(file_get_contents('php://input'),true);

          /*=====Validation-Rules=====*/
          $config_rules = array(

                array(

                 'field' => 'is_favourite',
                 'label' => 'is_favourite',
                 'rules' => 'required'
                ),
                array(

                 'field' => 'restaurant_id',
                 'label' => 'restaurant_id',
                 'rules' => 'required|trim|integer|greater_than[0]'
                )
          );
          /*=====Validation-Rules=====*/

          $this->form_validation->set_rules($config_rules,$_POST);

          if($this->form_validation->run() == FALSE) 
          {
              $first_key   = array_key_first($this->form_validation->error_array());
              $first_error = $this->form_validation->error_array()[$first_key];

              /*================response/*================*/ 
              http_response_code(404);
              echo json_encode([

                          "result"   => Api::FAIL,
                          "message"  => $first_error
                      ]);
              return;
              /*================response/*================*/ 
          }
          else
          {   
              /*=======================custom-validations==============================*/

                  /*======================check-email-expression==============*/
                  if(!empty($_POST['is_favourite']) && !in_array($_POST['is_favourite'],[0,1])) {
                        
                      /*================response/*================*/
                          http_response_code(404);
                          echo json_encode([

                                "result"  => Api::FAIL,
                                "message" => "is_favourite must be 0 or 1"
                          ]);
                          return;
                      /*================response/*================*/ 
                  }


                  /*======================check-email-expression==============*/

                    if(!empty($_POST['restaurant_id']) && !$this->chk_comapany_exist($_POST['restaurant_id'])) {
                        
                      /*================response/*================*/
                          http_response_code(404);
                          echo json_encode([

                                "result"  => Api::FAIL,
                                "message" => "restaurant_id doesnot exist"
                          ]);
                          return;
                      /*================response/*================*/ 
                    }

              /*=======================================================================*/

              $user = $this->auth_user;

              $this->db->select('*');
              $this->db->from('ortez_jbusinessdirectory_companies_favourite');
              $this->db->where(array('user_id' => $user['id'], 'company_id' => $_POST['restaurant_id']));
              $query = $this->db->get();

              if($_POST['is_favourite'] == 1) {

                  if($query->num_rows() > 0) {

                     /*================response/*================*/
                        http_response_code(404);
                        echo json_encode([

                              "result"  => Api::FAIL,
                              "message" => "Restaurant alreday added to favourite"
                        ]);
                        return;
                    /*================response/*================*/ 
                  }
                  else
                  {
                    //adding-to-favourite
                    $data = array('user_id' => $user['id'], 'company_id' => $_POST['restaurant_id']);
                    $this->db->insert('ortez_jbusinessdirectory_companies_favourite',$data);

                    /*================response/*================*/
                        http_response_code(200);
                        echo json_encode([

                              "result"  => Api::SUCCESS,
                              "message" => "Restaurant successfully added to favourite list"
                        ]);
                        return;
                    /*================response/*================*/

                  }

              }

              if($_POST['is_favourite'] != 1) {

                  if($query->num_rows() > 0) {

                    //removing-to-favourite
                    $this->db->where(array('user_id' => $user['id'], 'company_id' => $_POST['restaurant_id']));
                    $this->db->delete('ortez_jbusinessdirectory_companies_favourite');

                    /*================response/*================*/
                        http_response_code(200);
                        echo json_encode([

                              "result"  => Api::SUCCESS,
                              "message" => "Restaurant successfully removed from favourite list"
                        ]);
                        return;
                    /*================response/*================*/ 

                  }
                  else
                  {
                    /*================response/*================*/
                        http_response_code(404);
                        echo json_encode([

                              "result"  => Api::FAIL,
                              "message" => "Restaurant doesnot exist in favourite list"
                        ]);
                        return;
                    /*================response/*================*/ 
                  }
              }
              
          }
      }
      else
      {
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/ 
      }

  }

  /*
      =================================================
               COMPANY-Category
      =================================================
  */
   public function companyCategories($company_id) {

        $company_category_id = [];

        $this->db->select('categoryId');
        $this->db->from('ortez_jbusinessdirectory_company_category');
        $this->db->where('companyId',$company_id);
        $query = $this->db->get();

        if($query->num_rows() > 0 )
        {   
            $result = $query->result_array();

            foreach ($result as $key => $value) {
              
               $company_category_id[] = $value['categoryId'];
            }

            if(count($company_category_id)) {
                
                $this->db->select('*');
                $this->db->from('ortez_jbusinessdirectory_categories');
                $this->db->where_in('id',$company_category_id);
                $query2 = $this->db->get();

                if($query2->num_rows() > 0 ) {

                    return $query2->result_array();
                }
            }
        }

        return [];
   }


  /*
      =================================================
               COMPANY-PICTURES
      =================================================
  */
  public function companyPictures($company_id) {

      $company_pictures_arr = [];

      $this->db->select('*');
      $this->db->from('ortez_jbusinessdirectory_company_pictures');
      $this->db->where('companyId',$company_id);
      $query = $this->db->get();

      if($query->num_rows() > 0) {
         
          $company_pictures = $query->result();

          foreach ($company_pictures as $company_picture) {

              if($company_picture->picture_enable) {

                  $company_pictures_arr[] = $this->image_basePath.$company_picture->picture_path;
              }
          }  
      }

      return $company_pictures_arr;
  }


  /*
      =================================================
               COMPANY-Halal-Status
      =================================================
  */ 

  public function companyHalalStatus($company_id) {

      $this->db->select('*');
      $this->db->from('ortez_jbusinessdirectory_company_attributes');
      $this->db->where(['company_id' => $company_id,'attribute_id' => 15]);
      $query = $this->db->get();

      if($query->num_rows() > 0) {
           
           $result = $query->row_array();
           $value  = $result['value'];

           if(!empty($value) && !is_null($value)) {
               
               $this->db->select('*');
               $this->db->from('ortez_jbusinessdirectory_attribute_options');
               $this->db->where(['id' => $value,'attribute_id' => 15]);
               $query2 = $this->db->get();

               if($query2->num_rows() > 0) {

                   $result2 = $query2->row_array();

                    return $result2['name'];
               }
               
           }
      }

      return "";
  }

  /*
      =================================================
               COMPANY-Services
      =================================================
  */ 

  public function companyServices($company_id) {

      $services_arr = [];

      $this->db->select('*');
      $this->db->from('ortez_jbusinessdirectory_company_attributes');
      $this->db->where(['company_id' => $company_id,'attribute_id' => 13]);
      $query = $this->db->get();

      if($query->num_rows() > 0) {
           
           $result = $query->row_array();
           $values  = $result['value'];

           if(!empty($values) && !is_null($values)) {

                $values_arr = explode(",",$values);
               
               $this->db->select('*');
               $this->db->from('ortez_jbusinessdirectory_attribute_options');
               $this->db->where('attribute_id',13);
               $this->db->where_in('id',$values_arr);

               $query2 = $this->db->get();

               if($query2->num_rows() > 0) {

                   $result2 = $query2->result_array();

                   foreach ($result2 as $key => $res) {
                     
                       $services_arr[] = $res['name'];
                   }
               }
               
           }
      }

      return $services_arr;
  }  




  /*
      =================================================
               STATE-LIST
      =================================================
  */
  public function statesList() {

      if($this->input->server('REQUEST_METHOD') == "GET") {

         $search = $this->input->get('search');
         
         $this->db->select('id,name');
         $this->db->from('ortez_jbusinessdirectory_attribute_options');
         $this->db->where('attribute_id',10);
         if(!empty($search)) {

            $this->db->like('name',$search);
         }
         $query = $this->db->get();
         $row_count = $query->num_rows(); 
         if($row_count > 0) {
            
            $result = $query->result_array();
            
            /*================response/*================*/
            http_response_code(200);
            echo json_encode([

                  "result"  => Api::SUCCESS,
                  "message" => $row_count." result found",
                  "data"    => $result
            ],JSON_NUMERIC_CHECK);
            return;
            /*================response/*================*/
         }
         else
         { 
            /*================response/*================*/
              http_response_code(200);
              echo json_encode([

                   "result" => Api::SUCCESS,
                   "message" => "No data found"
              ]);
              return;
            /*================response/*================*/  
         }

      }
      else
      {
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/  
      }
  }

  /*
      =================================================
               COMPANY-RATING
      =================================================
  */ 

  public function companyRating($company_id) {

      $services_arr = [];

      $this->db->select('*');
      $this->db->from('ortez_jbusinessdirectory_company_reviews');
      $this->db->where(['itemId' => $company_id]);
      $query = $this->db->get();

      $row_num = $query->num_rows();

      if($row_num > 0) {
         
         $sum_of_rating = 0;
         $total_of_rating = 5 * $row_num;  

         $rows = $query->result_array();

         foreach ($rows as $row) {

            $sum_of_rating += $row['rating'];
         }

         if($sum_of_rating > 0) {
             
            return ($sum_of_rating * 5/ $total_of_rating);
           
         }

      }

      return 0.0 ;
  }


  /*
      =================================================
               COMPANY-US-STATE
      =================================================
  */ 

  public function companyUsState($company_id) { 

     $response = ["state_name" => "", "state_id" => Null];

      $this->db->select('*');
      $this->db->from('ortez_jbusinessdirectory_company_attributes');
      $this->db->where(['company_id' => $company_id,'attribute_id' => 10]);
      $query = $this->db->get();

      if($query->num_rows() > 0) {
           
           $result = $query->row_array();
           $value  = $result['value'];

           if(!empty($value) && !is_null($value)) {
               
               $this->db->select('*');
               $this->db->from('ortez_jbusinessdirectory_attribute_options');
               $this->db->where(['id' => $value,'attribute_id' => 10]);
               $query2 = $this->db->get();

               if($query2->num_rows() > 0) {

                   $result2 = $query2->row_array();

                   $response["state_name"] = $result2["name"];
                   $response["state_id"]   = $result2["id"];
               }
               
           }
      }

      return $response;
  }

  

  /*
      =================================================
               ORDER-LINK 
      =================================================
  */ 

  public function orderLink($company_id) {

      $services_arr = [];

      $this->db->select('*');
      $this->db->from('ortez_jbusinessdirectory_company_attributes');
      $this->db->where(['company_id' => $company_id,'attribute_id' => 12]);
      $query = $this->db->get();

      if($query->num_rows() > 0) {

         $result = $query->row_array();

         return $result['value'];
      }

      return "" ;
  }  

  /*
      =================================================
               FOOD-TYPES
      =================================================
  */
  public function foodTypes() {

     
    if($this->input->server('REQUEST_METHOD') == "GET") {

      $search = $this->input->get('search');
       
      $this->db->select('name,id');
      $this->db->from('ortez_jbusinessdirectory_categories');
      $this->db->where(array('published' => '1', 'level' => '1', 'type' => '1'));
      if(!empty($search)) {

        $this->db->like('name',$search);
      }
      $query = $this->db->get();
      $row_count = $query->num_rows(); 
      if($row_count > 0) {
          
          $result = $query->result_array();
         
         /*================response/*================*/
          http_response_code(200);
          echo json_encode([

                "result"  => Api::SUCCESS,
                "message" => $row_count." result found",
                "data"    => $result
          ],JSON_NUMERIC_CHECK);
          return;
        /*================response/*================*/ 
       }
       else
       { 
          /*================response/*================*/
            http_response_code(200);
            echo json_encode([

                 "result" => Api::SUCCESS,
                 "message" => "No data found"
            ]);
            return;
          /*================response/*================*/  
       }

    }
    else
    {
      /*================response/*================*/
        http_response_code(404);
        echo json_encode([

              "result"  => Api::FAIL,
              "message" => "Invalid method type"
        ]);
        return;
      /*================response/*================*/  
    }

  }

  
  /*
      =================================================
              COMPANY-REVIEWS-LIST
      =================================================
  */
  public function companyReviews() {

      if($this->input->server('REQUEST_METHOD') == 'POST') {

          $_POST = json_decode(file_get_contents('php://input'),true);

          /*=====================Validation-Rules===================*/
            $config_rules = array(

                array(

                 'field' => 'restaurant_id',
                 'label' => 'restaurant id',
                 'rules' => 'required|integer|greater_than[0]'
                ),

                array(

                 'field' => 'page',
                 'label' => 'page',
                 'rules' => 'numeric|greater_than[0]'
                ),

                array(

                 'field' => 'per_page',
                 'label' => 'per_page',
                 'rules' => 'numeric|greater_than[0]|less_than[100]'
                ),
            );
          /*=====================Validation-Rules===================*/

          $this->form_validation->set_rules($config_rules,$_POST);

          if($this->form_validation->run() == FALSE) 
          {    

              $first_key   = array_key_first($this->form_validation->error_array());
              $first_error = $this->form_validation->error_array()[$first_key];

              /*================response/*================*/ 
              http_response_code(404);
              echo json_encode([

                          "result"   => Api::FAIL,
                          "message"  => $first_error
                      ]);
              return;
              /*================response/*================*/ 
          }
          else
          {   
              $restaurant_id = $_POST['restaurant_id'];

              if(!empty($restaurant_id) && !$this->chk_comapany_exist($restaurant_id)) {
                        
                  /*================response/*================*/
                      http_response_code(404);
                      echo json_encode([

                            "result"  => Api::FAIL,
                            "message" => "restaurant_id doesnot exist"
                      ]);
                      return;
                  /*================response/*================*/ 
              }

              /*====================Pagination=======================*/
              $page            = 1;
              $result_per_page = 5;

              if(isset($_POST['page']) && $_POST['page'] > 0) {
                  
                  $page = $_POST['page'];
              }

              if(isset($_POST['per_page']) && $_POST['per_page'] > 0) {
                 
                 $result_per_page = $_POST['per_page'];
              }

              $page_first_result = ($page-1) * $result_per_page;
              $recordCount       = $this->db
                                        ->query('SELECT * FROM ortez_jbusinessdirectory_company_reviews where itemId='.$restaurant_id)
                                        ->num_rows();  

                    /*====================CHECK-RECORD-COUNT=======================*/
                      if($recordCount == 0) {
                        
                        /*================response/*================*/  
                        http_response_code(200);
                        echo json_encode([

                                "result"  => Api::SUCCESS,
                                "message" => "No Data Found"
                        ]);
                        return;
                        /*================response/*================*/ 
                      }
                    /*====================CHECK-RECORD-COUNT=======================*/
                                                             
              $number_of_page    = ceil ( $recordCount / $result_per_page); 
              /*====================Pagination=======================*/

              $this->db->select('oj_company_reviews.*,
                                 o_users.name,
                                 o_users.username,
                                 o_users_api.first_name,
                                 o_users_api.last_name,
                                ');
              $this->db->from('ortez_jbusinessdirectory_company_reviews as oj_company_reviews');
              $this->db->join('ortez_users as o_users', 'o_users.id = oj_company_reviews.userId', 'left');
              $this->db->join('ortez_users_api as o_users_api', 'o_users_api.ortez_users_id = o_users.id', 'left');
              $this->db->order_by("oj_company_reviews.id", "asc");
              $this->db->where('oj_company_reviews.itemId',$restaurant_id);
              $this->db->limit($result_per_page,$page_first_result);
              $query = $this->db->get();

              $num_Count = $query->num_rows();

              if($num_Count > 0) {

                  $data = array();

                  $rows = $query->result();

                  $sum_of_rating = 0;

                  $total_of_rating = $num_Count * 5;

                  foreach ($rows as $row) {

                      $sum_of_rating += $row->rating;
                      
                      $data[] = [
                                    "id"          => (int)$row->id,
                                    "rating"      => $row->rating,
                                    "description" => (string)$row->description,
                                    "user"        => [
                                                         "id"         => (int)$row->userId,
                                                         "name"       => (string)$row->name,
                                                         "username"   => (string)$row->username,
                                                         "first_name" => (string)$row->first_name,
                                                         "last_name"  => (string)$row->last_name
                                                     ]
                                ];
                  }

                  $avg_rating =$sum_of_rating * 5/ $total_of_rating;

                  $avg_rating = number_format($avg_rating,1,'.',''); 
                  $avg_ratingsss = (float)($avg_rating);
                  // var_dump($avg_ratingsss);
                  // die();
                  /*================response/*================*/ 
                  http_response_code(200);
                  $dataArr = [

                       "result"          => Api::SUCCESS,
                       "message"         => "Data found",
                       "average_rating"  => $avg_ratingsss,
                       "data"            => [
                                               "data"         => $data,
                                               "current_page" => $page,
                                               "last_page"    => $number_of_page,
                                               "per_page"     => $result_per_page,
                                               "total"        => $recordCount
                                            ],
                  ];
                  ini_set('precision', 10);
                  ini_set('serialize_precision', 10);
                  echo json_encode($dataArr,JSON_NUMERIC_CHECK);
                  return;
                  /*================response/*================*/ 

              }
          }
          
          /*================response/*================*/ 
          http_response_code(200);
          echo json_encode([

                "result"  => Api::SUCCESS,
                "message" => "No Data Found"
          ]);
          return;
          /*================response/*================*/ 
          
      }
      else
      {
        /*================response/*================*/ 
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/   
      }
  }

  /*
      =================================================
              ADD-COMPANY-REVIEW
      =================================================
  */
  public function addCompanyReviews() {


      if($this->input->server('REQUEST_METHOD') == 'POST') {

          /*======check-authorize=====*/
          if(!$this->isAuthorize) {

            http_response_code(404);
            echo json_encode([

                "result"  => false,
                "message" => "Invalid Authentication"
            ]);

            return;
          }
          /*======check-authorize=====*/

        $_POST = json_decode(file_get_contents('php://input'),true);

        $rules =  array(

              array(
                  
                'field' => 'restaurant_id',
                'label' => 'restaurant_id',
                'rules' => 'required|trim|numeric'
              ),
              array(
                  
                'field' => 'rating',
                'label' => 'rating',
                'rules' => 'required|trim|numeric|greater_than[0]|less_than[6]'
              ),
              array(
                  
                'field' => 'description',
                'label' => 'description',
                'rules' => 'required|trim|min_length[1]|max_length[500]'
              )
        );

        $this->form_validation->set_rules($rules,$_POST);

        if($this->form_validation->run() == FALSE) 
        {   
            $first_key   = array_key_first($this->form_validation->error_array());
            $first_error = $this->form_validation->error_array()[$first_key];

            /*================response/*================*/
              http_response_code(404);
              echo json_encode([

                          "result"   => Api::FAIL,
                          "message"  => $first_error
                      ]);
              return;
            /*================response/*================*/ 
        }
        else
        {  
            /*=======================custom-validations==============================*/

                  /*======================check-email-expression==============*/

                    if(!empty($_POST['restaurant_id']) && !$this->chk_comapany_exist($_POST['restaurant_id'])) {
                        
                      /*================response/*================*/
                          http_response_code(404);
                          echo json_encode([

                                "result"  => Api::FAIL,
                                "message" => "restaurant_id doesnot exist"
                          ]);
                          return;
                      /*================response/*================*/ 
                    }

           /*=======================================================================*/

            $user = $this->auth_user;

            $data = array(
                 
                 'name'          => $user['name'],
                 'description'   => $_POST['description'],
                 'userId'        => $user['id'],
                 'itemId'        => $_POST['restaurant_id'],
                 'rating'        => $_POST['rating'],
                 'approved'      => 2,
            );

            $this->db->insert('ortez_jbusinessdirectory_company_reviews',$data);
            
            /*================response/*================*/
            http_response_code(200);
            echo json_encode([

                    "result"  => Api::SUCCESS,
                    "message" => "Review is created successfully"
              ]);
            return;
            /*================response/*================*/
        }

      }
      else
      {
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/  
      }
  }
  

  /*
    =================================================
             USER-PROFILE
    =================================================
  */
  public function userProfile() {
      
      
      if($this->input->server('REQUEST_METHOD') == 'GET') {
        
          /*======check-authorize=====*/
          if(!$this->isAuthorize) {

            http_response_code(404);
            echo json_encode([

                "result"  => false,
                "message" => "Invalid Authentication"
            ]);

            return;
          }
          /*======check-authorize=====*/
         
          $user = $this->auth_user;
          
          /*================response/*================*/
            http_response_code(200);
            echo json_encode([

                  "result"  => Api::SUCCESS,
                  "message" => "User profile",
                  "data"    => [
                                  "id"           => (int)$user['id'],
                                  "first_name"   => isset($user['first_name'])   ? (string)$user['first_name']   : "",
                                  "last_name"    => isset($user['last_name'])    ? (string)$user['last_name']    : "",
                                  "email"        => isset($user['email'])        ? (string)$user['email']        : "",
                                  "state"        => isset($user['state'])        ? (string)$user['state']        : "",
                                  "phone_number" => isset($user['phone_number']) ? (string)$user['phone_number'] : "",
                                  "is_verify"    => isset($user['block'])        ? (string)!$user['block'] : '0',
                                  "device_type"  => isset($user['device_type'])  ? (string)$user['device_type']  : "",
                               ]
            ]);
            return;
          /*================response/*================*/
      }
      else
      {
        /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/  
      }    

  }

  public function userProfileUpdate() {
      
    if($this->input->server('REQUEST_METHOD') == 'POST') {

      /*======check-authorize=====*/
        if(!$this->isAuthorize) {

          http_response_code(404);
          echo json_encode([

              "result"  => false,
              "message" => "Invalid Authentication"
          ]);

          return;
        }
      /*======check-authorize=====*/

      $_POST = json_decode(file_get_contents('php://input'),true);

      $rules =  array(

                      array(
                            
                          'field' => 'first_name',
                          'label' => 'Firstname',
                          'rules' => 'trim|min_length[1]|max_length[200]'
                      ),
                      array(
                            
                          'field' => 'last_name',
                          'label' => 'Lastname',
                          'rules' => 'trim|min_length[1]|max_length[200]'
                      ),
                      array(
                            
                          'field' => 'email',
                          'label' => 'Email',
                          'rules' => 'trim|min_length[4]|max_length[200]'
                      ),
                      array(

                          'field' => 'state',
                          'label' => 'State',
                          'rules' => 'trim|min_length[1]|max_length[200]'
                      ),
                      array(
                          
                          'field' => 'phone_number',
                          'label' => 'Phone number',
                          'rules' => 'trim|min_length[5]|max_length[15]'
                      )
      );

      $this->form_validation->set_rules($rules,$_POST);

      if($this->form_validation->run() == FALSE) {
          
        $first_key   = array_key_first($this->form_validation->error_array());
        $first_error = $this->form_validation->error_array()[$first_key];

        /*================response/*================*/
          http_response_code(403); 
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => $first_error

              ]);
          return;
        /*================response/*================*/    
      }
      else
      {
          $first_name   = isset($_POST['first_name'])     ? $_POST['first_name']    : "";
          $last_name    = isset($_POST['last_name'])      ? $_POST['last_name']     : "";
          $email        = isset($_POST['email'])          ? $_POST['email']         : "";
          $state        = isset($_POST['state'])          ? $_POST['state']         : "";
          $phone_number = isset($_POST['phone_number'])   ? $_POST['phone_number']  : "";

          if(empty($first_name) && empty($last_name) && empty($email) && empty($state) && empty($phone_number)) {
             
            /*================response/*================*/
                http_response_code(404);
                echo json_encode([

                      "result"  => Api::FAIL,
                      "message" => "Invalid parameters"
                ]);
                return;
            /*================response/*================*/

          }
          else
          {
              if(!empty($email) && !$this->chk_email_expression($email)) {
                  
                /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Invalid email"
                    ]);
                    return;
                /*================response/*================*/ 
              }


              if(!empty($phone_number) && !$this->chk_phone_expression($phone_number)) {
                  
                /*================response/*================*/
                    http_response_code(404);
                    echo json_encode([

                          "result"  => Api::FAIL,
                          "message" => "Invalid phone number"
                    ]);
                    return;
                /*================response/*================*/ 
              }
              
              /*============Auth-USER=============*/
                        $user = $this->auth_user;
              /*============Auth-USER=============*/
              
              $requestData = array();

              if(!empty($first_name))   { $requestData['first_name']   = $first_name;   }
              if(!empty($last_name))    { $requestData['last_name']    = $last_name;    }
              if(!empty($email))        { $requestData['email']        = $email;        }
              if(!empty($state))        { $requestData['state']        = $state;        }
              if(!empty($phone_number)) { $requestData['phone_number'] = $phone_number; }

              $isChange = false;

              foreach ($requestData as $key => $value) {
                 
                   if(isset($user[$key]) && $user[$key]!= $value) {

                      $isChange = true;
                      break;
                   }
              }
              
              if(!$isChange) 
              {
             
                  /*================response/*================*/
                      http_response_code(404);
                      echo json_encode([

                            "result"  => Api::FAIL,
                            "message" => "Please provide different value to update"
                      ]);
                      return;
                  /*================response/*================*/

              }

              /*==========check-if-email-phone_number-already-exist===========*/

              if(!empty($requestData['email']) || !empty($requestData['phone_number']))
              {
                  $this->db->select('ortez_users.*');
                  $this->db->from('ortez_users');
                  $this->db->join('ortez_users_api','ortez_users.id = ortez_users_api.ortez_users_id','left');
                  if(!empty($requestData['email']))
                  {
                    $this->db->where('ortez_users.email',$requestData['email']);
                  }
                  if(!empty($requestData['phone_number']))
                  {
                    $this->db->or_where('ortez_users_api.phone_number',$requestData['phone_number']);
                  }
                  $this->db->where('ortez_users.id !=',$user['id']);

                  $query = $this->db->get();
                  
                  if($query->num_rows() > 0) {
                    
                    /*================response/*================*/
                      http_response_code(404);
                      echo json_encode([

                            "result"  => Api::FAIL,
                            "message" => "Email or Phone number already exist"
                      ]);
                      return;
                    /*================response/*================*/ 

                  }
              }
              
              $email_send_message = '';

              if(!empty($requestData['email'])) {
                
                  try
                  {
                    /*======================Update-Email-And-Block-User===================*/
                    $this->db->where('id',$user['id']);
                    $this->db->update('ortez_users',array('email' => $requestData['email'],'block' => 1));

                    /*======================reset-tokens===================*/
                    $this->db->where('ortez_users_id',$user['id']);
                    $this->db->update('ortez_users_api',array('tokens' => null));

                    $this->sendVerificationEmail($user['id']);
                    $email_send_message = ' and verification email link sent to provided email';
                  }
                  catch(Exception $e)
                  {
                      /*================response/*================*/
                          http_response_code(404);
                          echo json_encode([

                                "result"  => Api::FAIL,
                                "message" => "Error while sending email",
                                "data"    => $e->getMessage()
                          ]);
                          return;
                      /*================response/*================*/
                  }
              }
             
              
              if(isset($requestData['email'])) {

                 unset($requestData['email']);
              }

              if(count($requestData) > 0)
              {
                 $this->db->where('ortez_users_id',$user['id']);
                 $this->db->update('ortez_users_api',$requestData);
              }
              
              /*=================update-user====================*/
              $this->db->select('
                           ortez_users.*,
                           ortez_users_api.first_name,
                           ortez_users_api.last_name,
                           ortez_users_api.state,
                           ortez_users_api.phone_number,
                           ortez_users_api.tokens,
                           ortez_users_api.fp_token
                           ');
              $this->db->from('ortez_users');
              $this->db->join('ortez_users_api','ortez_users_api.ortez_users_id = ortez_users.id','left');
              $this->db->where(array('ortez_users.id' => $user['id']));
              $query = $this->db->get();

              $row = $query->row_array();

              $response = [

                "id"            => isset($row["id"])           ? (int)$row["id"]           : "",
                "first_name"    => isset($row["first_name"])   ? (string)$row["first_name"]   : "",
                "last_name"     => isset($row["last_name"])    ? (string)$row["last_name"]    : "",
                "email"         => isset($row["email"])        ? (string)$row["email"]        : "",
                "state"         => isset($row["state"])        ? (string)$row["state"]        : "",
                "phone_number"  => isset($row["phone_number"]) ? (string)$row["phone_number"] : "",
                "is_verify"     => isset($row["block"])        ? (string)!$row["block"]       : '0',
                "device_type"   => isset($user["device_type"]) ? (string)$user["device_type"]  : "",
              ];

              /*================response/*================*/
                  http_response_code(200);
                  echo json_encode([

                        "result"  => Api::SUCCESS,
                        "message" => "User updated successfully".$email_send_message,
                        "data"    => $response
                  ]);
                  return;
              /*================response/*================*/
          }
      } 

    }
    else
    {
       /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
       /*================response/*================*/ 
    }  
  }
  
  /*
    =================================================
              UPDATE-DEVICE-TOKEN
    =================================================
  */
  public function updateDeviceToken()
  {
      if($this->input->server('REQUEST_METHOD') == 'POST') {
          
           $_POST = json_decode(file_get_contents('php://input'),true);

          /*======check-authorize=====*/
            if(!$this->isAuthorize) {

              http_response_code(404);
              echo json_encode([

                  "result"  => false,
                  "message" => "Invalid Authentication"
              ]);

              return;
            }
          /*======check-authorize=====*/

          $rules = array(

                array(

                     'field' => 'device_type',
                     'label' => 'Device Type',
                     'rules' => 'required|trim|min_length[1]|max_length[200]'
                ),
                array(

                     'field' => 'device_token',
                     'label' => 'Device Token',
                     'rules' => 'required|trim|min_length[1]|max_length[200]'
                ),
          );

          $this->form_validation->set_rules($rules,$_POST);

          if($this->form_validation->run() == FALSE) {
                
            $first_key   = array_key_first($this->form_validation->error_array());
            $first_error = $this->form_validation->error_array()[$first_key];

            /*================response/*================*/
                http_response_code(403); 
                echo json_encode([

                      "result"  => Api::FAIL,
                      "message" => $first_error

                    ]);
                return;
            /*================response/*================*/    
          }
          else
          {   
              /*=======================custom-validations==============================*/

                /*======================check-email-expression==============*/

                  if(!empty($_POST['device_type']) && !$this->chk_device_type_expression($_POST['device_type'])) {
                      
                    /*================response/*================*/
                        http_response_code(404);
                        echo json_encode([

                              "result"  => Api::FAIL,
                              "message" => "Device type must be android or ios"
                        ]);
                        return;
                    /*================response/*================*/ 
                  }

              /*=======================================================================*/

              $user   = $this->auth_user;
              $token  = $user['token'];
              $tokens = json_decode($user['tokens']);

              foreach ($tokens as $tokenData) {
                  
                  if($tokenData->jwt == $token)
                  {
                      $tokenData->device_type  = $_POST['device_type'];
                      $tokenData->device_token = $_POST['device_token'];
                      break;
                  }
              }

              $tokens = json_encode($tokens);

              $this->db->where('ortez_users_id',$user['id']);
              $this->db->update('ortez_users_api',array('tokens' => $tokens));

              /*================response/*================*/
                http_response_code(200);
                echo json_encode([

                      "result"  => Api::SUCCESS,
                      "message" => "device-type/device-token updated successfully"
                ]);
                return;
              /*================response/*================*/ 
            
          }
      }
      else
      {
          /*================response/*================*/
          http_response_code(404);
          echo json_encode([

                "result"  => Api::FAIL,
                "message" => "Invalid method type"
          ]);
          return;
        /*================response/*================*/ 
      } 
  }

  /*
    =================================================
               USER-LOGOUT
    =================================================
  */
  public function userLogout() {

      if($this->input->server('REQUEST_METHOD') == 'GET')
      { 
            /*======check-authorize=====*/
            if(!$this->isAuthorize) {

              http_response_code(404);
              echo json_encode([

                  "result"  => Api::FAIL,
                  "message" => "Invalid Authentication"
              ]);

              return;
            }
            /*======check-authorize=====*/
            
            $user = $this->auth_user;
            /*=================delete-Access-Token==================*/
            $this->removeAccessToken($user['id'],$user['token']);


            /*================response/*================*/
              http_response_code(200);
              echo json_encode([

                    "result"  => Api::SUCCESS,
                    "message" => "Successfully logout"
              ]);
              return;
           /*================response/*================*/

      }
      else
      {
          /*================response/*================*/
            http_response_code(404);
            echo json_encode([

                  "result"  => Api::FAIL,
                  "message" => "Invalid method type"
            ]);
            return;
         /*================response/*================*/  
      }
  }


  /*
    =================================================
              SEND-VERIFICATION-EMAIL
    =================================================
  */
  public function sendVerificationEmail($userId = 179) {

    $this->db->select('*');
    $this->db->from('ortez_users');
    $this->db->where('id',$userId);
    $query = $this->db->get();

    if($query->num_rows() > 0)
    {
        $row = $query->row_array();

        /*=====link-generate=====*/
         $verify_token = $this->generateJWTToken([ 'id' => $row['id'],'email' => $row['email'] ]);
         $email_verification_link = base_url().'v1/user/email/verify/'.$verify_token;
        /*=====link-generate=====*/

        $message = $this->load->view('email/verify',['email_verification_link' => $email_verification_link],true);
        
        $this->sendMail($row['email'],'email verification mail',$message);

    }
    else
    {
        throw new Exception("User does not exist");   
    }                 
  }
  

   /*
    =================================================
            VERIFY-EMAIL
    =================================================
  */
  public function verifyEmail($token) {
      
    try
    {
        $jwt = new JWT();
        $result = $jwt->decode($token,$this->jwt_secret, $verify = true);
        
        $iat = $result->iat;
        $exp = $result->exp;
        $now = strtotime("now"); 

        /*=====check-validity=====*/
        if($iat < $now && $now > $exp) {
          
          http_response_code(404);  
          echo json_encode(['message' => 'TokenExpired']);
          return;

        }
        /*=====check-validity=====*/
    
        $email = $result->email;
        $id    = $result->id;
             
        /*=====check-user-exist-in-db=====*/
        $this->db->select('
                           ortez_users.*,
                           ortez_users_api.first_name,
                           ortez_users_api.last_name,
                           ortez_users_api.state,
                           ortez_users_api.phone_number,
                           ortez_users_api.tokens,
                           ortez_users_api.fp_token
                         ');
        $this->db->from('ortez_users');
        $this->db->join('ortez_users_api','ortez_users_api.ortez_users_id = ortez_users.id','left');
        $this->db->where('ortez_users.email', $email);
        $this->db->where('ortez_users.id', $id);
        $query = $this->db->get();

        if($query->num_rows() > 0) {
                    
          $row  = $query->row_array();
          $this->db->where('id',$row['id']);
          $this->db->update('ortez_users',array('block' => 0));

          /*================response/*================*/ 
           http_response_code(200); 
           echo json_encode(['message' => 'Email verified successfully']);
           return;
          /*================response/*================*/
        }
        else
        {
          /*================response/*================*/ 
           http_response_code(404); 
           echo json_encode(['message' => 'User does not exist']);
           return;
          /*================response/*================*/
        }        
    }
    catch(Exception $e)
    {
        /*================response/*================*/ 
         http_response_code(404); 
         echo json_encode(['message' => 'Invalid request token']);
         return;
        /*================response/*================*/
    }    
  }


  /*
    =================================================
               REGISTER-VALIDATION-RULES
    =================================================
  */
  protected function registerValidationRules() {


        $register_rules = array(

            array(
                  
                'field' => 'username',
                'label' => 'Username',
                'rules' => 'required|trim|min_length[1]|max_length[200]|is_unique[ortez_users.username]'
            ),
            array(

                 'field' => 'first_name',
                 'label' => 'Firstname',
                 'rules' => 'required|trim|min_length[1]|max_length[200]'
                ),
            array(

                 'field' => 'last_name',
                 'label' => 'Lastname',
                 'rules' => 'required|trim|min_length[1]|max_length[200]'
                ),
            array(

                 'field' => 'email',
                 'label' => 'Email',
                 'rules' => 'required|trim|min_length[4]|max_length[200]|is_unique[ortez_users.email]'
                ),
            array(

                 'field' => 'state',
                 'label' => 'State',
                 'rules' => 'required|trim|min_length[1]|max_length[200]'
                ),
            array(

                 'field' => 'phone_number',
                 'label' => 'Phone number',
                 'rules' => 'required|trim|min_length[5]|max_length[15]|is_unique[ortez_users_api.phone_number]'
                ),
            array(

               'field' => 'password',
               'label' => 'Password',
               'rules' => 'required|trim|min_length[5]|max_length[200]'
            ),
            array(

               'field' => 'device_type',
               'label' => 'Device Type',
               'rules' => 'required|trim|min_length[1]|max_length[200]'
            ),
            array(

               'field' => 'device_token',
               'label' => 'Device Token',
               'rules' => 'required|trim|min_length[1]|max_length[200]'
            ),
            array(

               'field' => 'otp',
               'label' => 'OTP',
               'rules' => 'required|trim|min_length[4]|max_length[4]'
            )      
      );

      return $register_rules;
    }


    /*
      =================================================
               LOGIN-VALIDATION-RULES
      =================================================
    */

    protected function loginValidationRules() {

        $login_rules = array(

            array(

                 'field' => 'email',
                 'label' => 'Email',
                 'rules' => 'required|trim|min_length[4]|max_length[200]'
                ),
            array(

               'field' => 'password',
               'label' => 'Password',
               'rules' => 'required|trim|min_length[1]|max_length[200]'
            ),
            array(

               'field' => 'device_type',
               'label' => 'Device Type',
               'rules' => 'required|trim|min_length[1]|max_length[200]'
            ),
            array(

               'field' => 'device_token',
               'label' => 'Device Token',
               'rules' => 'required|trim|min_length[1]|max_length[200]'
            )  
      );

      return $login_rules;
    }


    /*
      =================================================
                 GENERATE JWT TOKEN
      =================================================
    */

      protected function generateJWTToken($payload) {

        $date = new DateTime();
        $payload['iat'] = $date->getTimestamp();
        $payload['exp'] = $date->getTimestamp() + 60*60*500;

        $jwt = new JWT();
        $token = $jwt->encode($payload,$this->jwt_secret,$this->jwt_algo);

        return $token;
      }

    /*
      =================================================
                CHECK AUTHORIZATION
      =================================================
    */ 

    protected function checkAuthorization(&$auth_user,&$isAuthorize,&$error_message) {

      /*=====Autorization=====*/  
      $authorization = $this->input->request_headers()['Authorization'];

      if(!empty($authorization) && !is_null($authorization)) {

        $jwt_token = trim(str_replace('Bearer ','',$authorization));
        $jwt       = new JWT();
       
        try {

          $result  = $jwt->decode($jwt_token,$this->jwt_secret, $verify = true);
          if($result) {
            
              $iat = $result->iat;
              $exp = $result->exp;
              $now = strtotime("now");

              /*=====check-user-exist-in-db=====*/
              $this->db->select('
                                 ortez_users.*,
                                 ortez_users_api.first_name,
                                 ortez_users_api.last_name,
                                 ortez_users_api.state,
                                 ortez_users_api.phone_number,
                                 ortez_users_api.tokens,
                                 ortez_users_api.fp_token
                                 ');
              $this->db->from('ortez_users');
              $this->db->join('ortez_users_api','ortez_users_api.ortez_users_id = ortez_users.id','left');
              $this->db->where(array('ortez_users.id' => $result->id,'ortez_users.email' => $result->email));
              $query = $this->db->get();
 
              if($query->num_rows() > 0) {

                  $row  = $query->row_array();

                  $tokens = json_decode($row['tokens']);

                  if(!empty($tokens) && !is_null($tokens) && is_array($tokens) && count($tokens))
                  {
                      $isTokenExist = false;
                      /*==================check-token-exist-in-db==================*/
                        foreach ($tokens as $tokenData) {
                            
                            if($tokenData->jwt == $jwt_token){

                                $isTokenExist        = true;
                                $row['token']        = $tokenData->jwt;
                                $row['device_type']  = $tokenData->device_type;
                                $row['device_token'] = $tokenData->device_token;
                                break;
                            }
                        }
                      /*===========================================================*/
                       
                      if($isTokenExist)
                      {
                          /*===================check-token-expiry==================*/
                          if($iat < $now && $now > $exp) {
                                
                              $this->removeAccessToken($result->id,$jwt_token);
                              $isAuthorize   = false;
                              $error_message = 'Token Expired';
                              return;

                          }
                          else
                          {
                            
                            $auth_user = $row;
                            $isAuthorize = true;
                            return;
                          } 
                      }
                      else
                      {
                        $isAuthorize   = false;
                        $error_message = 'Invalid Authorization';
                        return;
                      }
                  }
                  else
                  {
                    $isAuthorize   = false;
                    $error_message = 'Invalid Authorization';
                    return;
                  }
                  
              }
              else
              {
                 $isAuthorize   = false;
                 $error_message = 'Invalid Authorization';
                 return;
              }        

          }
          else
          {
             $isAuthorize   = false;
             $error_message = 'Invalid Authorization';
             return;
          }

        }
        catch(Exception $e) {

          $error_message = $e->getMessage();
          $isAuthorize   = false;
          return;
        }

      }
      else
      {
        $isAuthorize   = false;
        $error_message = 'Invalid Authorization';
        return;
      }


    }
    

    /*
      =================================================
              REMOVE-ACCESS-TOKEN
      =================================================
    */
     protected function removeAccessToken($userId,$accessToken)
     {
          $this->db->select('ortez_users.*,ortez_users_api.tokens');
          $this->db->from('ortez_users');
          $this->db->join('ortez_users_api','ortez_users.id = ortez_users_api.ortez_users_id','left');
          $this->db->where('ortez_users.id',$userId);
          $query = $this->db->get();

          if($query->num_rows() > 0){

              $row    = $query->row_array();
              $tokens = json_decode($row['tokens']);

              if(!empty($tokens) && !is_null($tokens) && count($tokens) > 0)
              {   

                  $filter_tokens = array_filter($tokens,function($tokenData) use($accessToken) {

                      if($tokenData->jwt != $accessToken) { return true; }
                  });

                  if(count($filter_tokens) > 0)
                  {
                    $filter_tokens = json_encode($filter_tokens);
                  }
                  else
                  {
                    $filter_tokens = null;
                  }

                  $this->db->where('ortez_users_id',$row['id']);
                  $this->db->update('ortez_users_api',array('tokens' => $filter_tokens));
              }

          }

     } 


    /*
      =================================================
              PASSWORD-HASH
      =================================================
    */
    private function hash_password($password){
       return password_hash($password, PASSWORD_BCRYPT);
    }



    /*
      =================================================
              SEND-SMS
      =================================================
    */
    public function sendSMS($from,$to,$message) {
      
        $method      = 'POST';
        $requestUrl  =  "/2010-04-01/Accounts/".$this->SID."/Messages";
        $queryParams = [];
        $formParams  = [

            'To'   => $to,
            'From' => $from,
            'Body' => $message
        ];
        $headers     = [];
        $isJsonRequest = false;

        return $this->makeRequest($method,$requestUrl,$queryParams,$formParams,$headers,$isJsonRequest);

    }

  /*
      =================================================
              GENERATE-RANDOM-NUMBER
      =================================================
  */
  protected function generateRandomNumber($len = 6) {

      $ch = "0123456789";
      $l = strlen ($ch) - 1;
      $str = "";

      for ($i=0; $i < $len; $i++)
      {
          $x = rand (0, $l);
          $str .= $ch[$x];
      }

      return $str;
  }

  /*
      =================================================
              CHECK-IS-VALID-OTP
      =================================================
  */
  protected function isValidOtp($phone_number,$otp) {

       
      $this->db->select('*');
      $this->db->from('ortez_users_otp');
      $this->db->where(array('phone_number' => $phone_number,'otp' => $otp));
      $this->db->order_by("id", "desc");
      $query = $this->db->get();

      if($query->num_rows() > 0)
      {
         return true;
      }
      else
      {
         return false;
      }


  }

  /*
      =================================================
              REMOVE-OTP
      =================================================
  */
  protected function removeOtp($phone_number) {

    $this->db->where('phone_number',$phone_number);
    $this->db->delete('ortez_users_otp');
  }



  /*
      =================================================
              MAKE-REQUEST
      =================================================
  */
  public function makeRequest($method = 'GET',$requestUrl = '',$queryParams = [],$formParams = [], $headers = [], $isJsonRequest = false)
  {

      $url = $this->baseUri.$requestUrl;

      $ch = curl_init();

      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);

      if($method == 'POST') {

        curl_setopt($ch, CURLOPT_POST, 1);

        if(count($formParams) > 0)
        {
            if($isJsonRequest)
            {
               curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($formParams));
            }
            else
            {
               curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($formParams));
            }
        }
      }

      if(method_exists($this, 'resolveAuthorization'))
      {  
          $this->resolveAuthorization($queryParams, $formParams, $headers);
      }

      
      $headers[] = "cache-control: no-cache";
      $headers[] = "content-type: application/x-www-form-urlencoded";
      $headers[] = "Accept: application/json";

      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      $result = curl_exec($ch);
      $err    = curl_error($ch);

      if ($err) 
      {
        throw new Exception($err);
        return;
      } 
      else 
      { 

        $jsonRes  = json_encode(simplexml_load_string($result));
        $arrayRes = json_decode($jsonRes,true);
        
        if(isset($arrayRes['RestException'])) {
            
            throw new Exception($arrayRes["RestException"]["Message"]);
            return;
             
        }

        return true;
      }

  }


    /*
      =================================================
            RESOLVE AUTHORIZATION
      =================================================
    */
    public function resolveAuthorization(&$queryParams, &$formParams, &$headers)
    {  
        $headers[] = "Authorization:".$this->resolveAccessToken();
    }


    /*
      =================================================
            RESOLVE ACCESS TOKEN
      =================================================
    */
    public function resolveAccessToken()
    {
        $credentials = base64_encode("{$this->SID}:{$this->AUTH_TOKEN}");

        return "Basic {$credentials}";
    }


    /*
      =================================================
            CHECK-EMAIL-EXPRESSION
      =================================================
    */
    public function chk_email_expression($email)
    {
        if (1 !== preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $email))

        {
            $this->form_validation->set_message('chk_email_expression', '%s must be valid email');
            return FALSE;
        }

        else

        {
            return TRUE;
        }

    }

     /*
      =================================================
            CHECK-PHONE-EXPRESSION
      =================================================
    */

    public function chk_phone_expression($phone)
    {
        if (1 !== preg_match("/^\+[0-9]{9,15}$/ix", $phone))

        {
            $this->form_validation->set_message('chk_phone_expression', '%s must be valid phone');
            return FALSE;
        }

        else

        {
            return TRUE;
        }

    }

    /*
      =================================================
            CHECK-EMAIL-EXPRESSION
      =================================================
    */
    public function chk_device_type_expression($device_type)
    {
        $available_device_types = ['android','ios'];
        $device_type = $this->convert_lowercase($device_type);

        if(!in_array($device_type, $available_device_types)) {

           $this->form_validation->set_message('chk_device_type_expression', '%s must be android or ios');
           return FALSE;
        }
        else
        {
            return TRUE;
        }
    }


    public function chk_comapany_exist($restaurant_id) {

        if(empty($restaurant_id)) {

           $restaurant_id = -1;
        }

       // $count = $this->db->query('SELECT * FROM ortez_jbusinessdirectory_companies where id='.$restaurant_id)->num_rows();
        
        $this->db->select('*');
        $this->db->where('id',$restaurant_id);
        $this->db->from('ortez_jbusinessdirectory_companies');
        $query = $this->db->get();

        if($query->num_rows() == 0) {

           $this->form_validation->set_message('chk_comapany_exist', '%s not exist');
           return FALSE;
        }
        else
        {   
            $row = $query->row_array();

            if($row['approved'] != 2) {
               
              $this->form_validation->set_message('chk_comapany_exist', '%s not approved');
              return FALSE;

            }

            return TRUE;
        }
    }

    /*
      =================================================
            CONVERT-TO-LOWER-CASE
      =================================================
    */
    public function convert_lowercase($val) {
      return strtolower($val);
    }


     /*
      =================================================
            Send testMail
      =================================================
    */

      public function sendMail($to,$subject='',$message='') 
      {

           // Load PHPMailer library
          $this->load->library('phpmailer_lib');
          
          // PHPMailer object
          $mail = $this->phpmailer_lib->load();
          
          // SMTP configuration
          $mail->isSMTP();
          $mail->Host       = $this->Host;
          $mail->SMTPAuth   = $this->SMTPAuth;
          $mail->Username   = $this->Username;
          $mail->Password   = $this->Password;
          $mail->SMTPSecure = $this->SMTPSecure;
          $mail->Port       = $this->Port;
          
          $mail->setFrom($this->Username, '');
          $mail->addReplyTo($this->Username, '');
          
          // Add a recipient
          $mail->addAddress($to);
          
        // Add cc or bcc 
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');
          
          // Email subject
          $mail->Subject = $subject;
          
          // Set email format to HTML
          $mail->isHTML(true);
          
          // Email body content
          $mail->Body = $message;
          
          // Send email
          if(!$mail->send()){
             
            throw new Exception($mail->ErrorInfo);

          }else
          { 
            return true;
          }
            
      }


   /*
    =================================================
              Send Mail
    =================================================
    */
    // public function sendMail($to='',$subject='',$message='') {
      
    //   $email = mail($to,$subject,$message);

    //   if($email)
    //   {
    //     return true;
    //   }
    //   else
    //   {
    //     return false;
    //   }

    // }

        /*
      =================================================
              SEND-MAIL
      =================================================
    */
    // public function sendMail($to,$subject='',$message='')
    // {   
    //     $this->load->config('email');
    //     $this->load->library('email');
        
    //     $from    = $this->config->item('smtp_user');
    //     $to      = $to; ;
    //     $subject = $subject;
    //     $message = $message;

    //     $this->email->set_newline("\r\n");
    //     $this->email->from($from);
    //     $this->email->to($to);
    //     $this->email->subject($subject);
    //     $this->email->message($message);

    //     if($this->email->send()) {
          
    //       return true;
    //     } 
    //     else 
    //     {
    //       throw new Exception(show_error($this->email->print_debugger()));
    //     }
    // }

    public function test() 
    {
          $userId = 185;

          //             $this->db->from('ortez_jbusinessdirectory_companies_favourite');
          //             $this->db->where(array('user_id' => $user['id'],'company_id' => $company->id));
          //             $favQuery = $this->db->get();



          // $this->db->select('*');
          // $this->db->from('ortez_jbusinessdirectory_companies');
          // $this->db->join('ortez_jbusinessdirectory_companies_favourite')
          // $query = $this->db->get();

          // print_r($query->num_rows());

          $sql="SELECT * FROM `ortez_jbusinessdirectory_companies` c LEFT JOIN (SELECT userId,itemId,COUNT(itemId) AS CNT FROM `ortez_jbusinessdirectory_company_reviews` WHERE userId = 185 GROUP BY itemId) p ON c.id = p.itemId";       
                 
          $query = $this->db->query($sql);
          $dd = $query->result_array();

          print_r($dd);
    }
}


