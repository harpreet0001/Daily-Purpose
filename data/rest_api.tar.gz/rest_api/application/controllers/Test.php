<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * handles the admins
 * 
 * @since 1.0
 * @author DeDevelopers
 * @copyright Copyright (c) 2019, DeDevelopers, https://dedevelopers.com
 */
class Test extends ADMIN_Controller {
    private $guest_id;
    function __construct()
    {
        error_reporting(-1);
        parent::__construct();
    }
    public function test(){
        print_r(1);
        die();
    }
    
}