<?php

defined('BASEPATH') or exit('No direct script access allowed');

function testHelper()
{
	 print_r('test');die;
}