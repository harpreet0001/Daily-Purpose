<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <style>
    
.reset-password-content {
    max-width: 500px;
    padding: 50px;
    box-shadow: 0 0 10px rgb(0 0 0 / 50%);
    margin: 50px auto;
    border-radius: 10px;
}
.reset-password-content h2 {
    border-bottom: 2px solid #000;
    padding-bottom: 10px;
    font-size: 24px;
    text-align: center;
    line-height: 26px;
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 20px;
}
.reset-password-content form button.cstm-btn {
    background-color: #000!important;
    border: none!important;
    padding: 8px 10px;
    border-radius: 5px;
    color: #fff;
    min-width: 90px;
    font-size: 16px;
}
.reset-password-content label.error {
    color: red;
    font-size: 13px;
}
  </style>
</head>
<body>
  <section class="reset-password-sec">
    <div class="container">
      <div class="reset-password-content">
        <h2>Reset Password</h2>
      <?php echo validation_errors(); ?>
      <form action="<?php echo base_url();?>v1/reset/password?fp_token=<?php echo $fp_token; ?>" method="post" id="reset_password_form">
                	
          <div class="form-group">
          <p><?php echo $email; ?></p>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" name="password" id="password" placeholder="Passsword">
          </div>
         <div class="form-group">
            <label>Confirm Passsword</label>
            <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm password">
          </div>
      	  <button type="submit" class="cstm-btn">Send</button>
      </form>
      </div>
   </div>
  </section>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() { 

    $('#reset_password_form').validate({

        rules: {

          password: {
              required  : true,
              minlength : 5,
              maxlength : 50
          },
          confirm_password: {
              required  : true,
              minlength : 5,
              maxlength : 50,
              equalTo   : "#password"
          }

        }

      });
  })
</script>
</html>