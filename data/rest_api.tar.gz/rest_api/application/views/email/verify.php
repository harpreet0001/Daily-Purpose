<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Email Template</title>
</head>

<body style="margin: 0;">
    <div>
        <table class="table" style="border: 1px solid #f0efeb; border-collapse: collapse; width: 100%; max-width: 620px; margin: 0 auto; background-color: #f0efeb;" width="100%">
            
            <tbody style="background-color:#fff">
                <tr>
                    <td>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td style="font-size: 20px;line-height: 18px;color: #e63b2b;font-weight: 600;padding: 15px;border-bottom: 1px solid #f0efeb;">
                                    Email Verification Link</td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%">
                            <tbody>
                                <tr>
                                    <td colspan="" style="padding: 15px; width:100%">
                                        <a href="<?php echo $email_verification_link; ?>" target="_blank">click here</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                
            </tbody>
            
        </table>
    </div>


</body>

</html>