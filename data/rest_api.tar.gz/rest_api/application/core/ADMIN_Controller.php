<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ADMIN_Controller extends CI_Controller {

	/**
	 * Core Class for everthing controller of admin.
	 *
	 * this class is for running pre-codes before actual class.
	 *
	 * @$data is variable of this class and is inherited with childs
	 * this is a semi-global container of multiple objects|array|any
     * @copyright Copyright (c) 2019, DeDevelopers, https://dedevelopers.com
	*/
	// private $data = array();
	function __construct()
	{
		parent::__construct();
		error_reporting(1);
		$this->load->library('form_validation');
		$this->load->library('session');
        $this->load->helper('url');
        $this->load->database();
        $this->db->reconnect();

        $this->data['url'] = base_url();
		$this->data['assets'] = base_url()."resources/backend/";
		$this->data['root'] = base_url();
		$this->data['js'] = '';
		$this->data['jsfile'] = '';
		$this->data['sub'] = '';
	}

}
