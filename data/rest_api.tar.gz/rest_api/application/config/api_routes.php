<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*API*/
$route['v1/login']="api/Api/login";
$route['v1/register']="api/Api/register";
$route['v1/forgot/password']="api/Api/forgotPassword";
$route['v1/reset/password']="api/Api/resetPassword";
$route['v1/user/exist']="api/Api/checkUserExist";
$route['v1/resend/otp']="api/Api/resendOTP";
$route['v1/company/listing']="api/Api/companyListing";
$route['v1/states/list']="api/Api/statesList";
$route['v1/food/types']="api/Api/foodTypes";
$route['v1/company/detail']="api/Api/companyDetail";
$route['v1/company/reviews']="api/Api/companyReviews";
$route['v1/company/reviews/add']="api/Api/addCompanyReviews";
$route['v1/user/profile']="api/Api/userProfile";
$route['v1/user/profile/update']="api/Api/userProfileUpdate";
$route['v1/user/logout']="api/Api/userLogout";
$route['v1/user/change/password']="api/Api/changePassword";
$route['v1/user/device/token/update']="api/Api/updateDeviceToken";
$route['v1/user/email/verify/(:any)']="api/Api/verifyEmail/$1";
$route['v1/add/company/favourite']="api/Api/addCompantToFavourite";



