<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'protocol'     => 'mail',                   // 'mail', 'sendmail', or 'smtp'
    'smtp_host'    => 'mail.myzabihah.com',      //'smtp.mailtrap.io', 
    'smtp_port'    => 465,                      //2525,
    'smtp_user'    => 'noreply@myzabihah.com',  //'3d209a72d007e9',
    'smtp_pass'    => 'QQry7JxwzPDF7Z9822',     //'c34b63a1dcf59c',
    'smtp_crypto'  => 'tls', //can be 'ssl' or 'tls' for example
    'mailtype'     => 'html', //plaintext 'text' mails or 'html'
    'smtp_timeout' => '4', //in seconds
    //'charset'      => 'iso-8859-1',
    'wordwrap'     => TRUE
);